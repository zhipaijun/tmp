﻿# EBM 煤矿施工日志（班/日/月）优化版

- 需求：`../需求.md`　旧代码：`../code.txt`　甲方模板：`../骆驼山煤矿EBM项目施工日志.xls`
- 目标：.NET Framework 4.x / VB.NET（VB 2012 语法兼容，系统自带 vbc 可直接编译）

## 快速开始

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1   # 编译 out\EbmConstructionLog.exe
powershell -ExecutionPolicy Bypass -File .\run.ps1     # 9 个仿真场景 108 项断言
```

## 阅读顺序

1. `docs\优化说明.md` —— 需求映射、旧代码缺陷修复、架构、集成步骤、配置项、待确认问题
2. `src\ConstructionLogService.vb` —— 对外唯一入口（PLC 主循环调用这里）
3. `src\Program.vb` —— 仿真自测程序（模拟 PLC、9 个场景）
4. `log_config.ini` —— 现场参数（班次时间/锚护系数/故障过滤/工序改名）

## 验证与评审

- 自测：`run.ps1` 9 个仿真场景、108 项断言全部通过（退出码 0）
- 独立评审：`docs\reviews\优化代码评审.md`（FROZEN-6 定稿；C-01~C-08 全部闭环、阻断 0、结论"可交付"）
- 旧代码分析：`docs\reviews\旧代码-需求覆盖与缺陷分析.md`
- 甲方模板与原始需求/旧代码：`docs\原需求与旧代码\`
## 交付状态

- 9 个场景、108 项断言全部通过（跨班、跨日、跨月、泵停收尾、泵抖动、断电重启、待开班、配置驱动）
- 日志文件不长期占用（原子写/追加后立即关闭），任意时刻可拷贝
- 班次状态落盘，重启可恢复未结束工序与运行中故障