﻿# 运行自测/演示：在 out\demo 下生成三套日志样例并校验需求点
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$exe = Join-Path $root 'out\EbmConstructionLog.exe'
if (-not (Test-Path $exe)) { throw '请先运行 build.ps1' }

# 控制台按 UTF-8 输出中文
$OutputEncoding = [Console]::OutputEncoding = [Text.Encoding]::UTF8
& $exe
exit $LASTEXITCODE
