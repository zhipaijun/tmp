﻿Option Explicit On
Option Strict Off
Option Infer On
'==============================================================================
' 文件：DailyLogManager.vb
' 作用：日施工日志生成（跨日第一次送电后生成上一日日日志）
'
' 需求对应：
'   1) 日进尺 = 下位机掉电保存日进尺变量（缺失时用早/中班进尺累加回退）；
'   2) 早/中班进刀数量、耗时：优先 PLC 掉电保存计数，明细表回退；
'   3) 早/中班锚护数量、耗时：锚护工序次数 ×（顶锚5、帮锚6、锚索2），耗时按根数比例分摊（可配置）；
'   4) 日施工日志耗时不另建内存状态，全部由"工序明细表"累计；
'   5) 设备故障从"故障明细表"读取（单独建表维护）。
'==============================================================================

Imports System
Imports System.Collections.Generic
Imports System.Globalization
Imports System.Text

Namespace Ebm.ConstructionLog

    ''' <summary>日施工日志管理器（线程安全）</summary>
    Public Class DailyLogManager
        Private ReadOnly _config As LogConfig
        Private ReadOnly _options As LogOptions
        Private ReadOnly _fs As LogFileSystem
        Private ReadOnly _paths As LogPaths
        Private ReadOnly _tables As RecordTables
        Private ReadOnly _plc As IPlcIo
        Private ReadOnly _shiftMgr As ShiftLogManager
        Private ReadOnly _gate As New Object()

        Public Sub New(config As LogConfig, fs As LogFileSystem, paths As LogPaths, tables As RecordTables, plc As IPlcIo, shiftMgr As ShiftLogManager)
            _config = config
            _options = config.Options
            _fs = fs
            _paths = paths
            _tables = tables
            _plc = plc
            _shiftMgr = shiftMgr
        End Sub

        ''' <summary>该日是否有可生成日日志的数据</summary>
        Public Function HasDayData(day As Date) As Boolean
            If _tables.ReadProcesses(day).Count > 0 Then Return True
            If _tables.ReadFaults(day).Count > 0 Then Return True
            Return _shiftMgr.HasDayData(day)
        End Function

        ''' <summary>生成某日日施工日志并落日汇总表（重复生成幂等：表不重复、文件重写）</summary>
        Public Function GenerateDailyLog(day As Date, generatedAt As Date) As DailySummary
            SyncLock _gate
                Dim summary = BuildSummary(day, generatedAt)
                Dim text = BuildDailyReport(summary)
                _fs.WriteAllTextAtomic(_paths.DailyLogFile(day), text)
                _tables.AppendDailySummary(summary)
                Return summary
            End SyncLock
        End Function

        ''' <summary>用已落表的日汇总重渲染日日志文本（避免用 PLC 当前计数回写历史日；用于文本缺失/过期自愈）</summary>
        Public Function WriteReportFromSummary(summary As DailySummary) As Boolean
            If summary Is Nothing Then Return False
            SyncLock _gate
                _fs.WriteAllTextAtomic(_paths.DailyLogFile(summary.LogDate), BuildDailyReport(summary))
                Return True
            End SyncLock
        End Function

        ''' <summary>若该日已有日汇总但日志文本缺失，则用汇总重渲染补齐（自愈）</summary>
        Public Function EnsureDailyReportFile(day As Date) As Boolean
            SyncLock _gate
                If _fs.FileExists(_paths.DailyLogFile(day)) Then Return True
                Dim summary = _tables.ReadDailySummary(day)
                If summary Is Nothing Then Return False
                _fs.WriteAllTextAtomic(_paths.DailyLogFile(day), BuildDailyReport(summary))
                Return True
            End SyncLock
        End Function

        ''' <summary>只生成文本（测试/预览）</summary>
        Public Function BuildDailyReportText(day As Date, generatedAt As Date) As String
            SyncLock _gate
                Return BuildDailyReport(BuildSummary(day, generatedAt))
            End SyncLock
        End Function

        '==================================================================
        ' 汇总计算
        '==================================================================
        Private Function BuildSummary(day As Date, generatedAt As Date) As DailySummary
            Dim logDate = day.Date
            Dim dayStart = logDate
            Dim dayEnd = logDate.AddDays(1)
            Dim processes = _tables.ReadProcesses(logDate)
            Dim faults = CollectDayFaults(logDate)

            '--- 进刀 / 锚护次数：优先取 PLC 掉电保存变量，取不到时用明细回退 ---
            '说明：仅"昨日/当日"使用 PLC 当前计数（正常路径，PLC 尚未清零）；
            '      补生成更早的历史日时改用明细表，避免 PLC 当前值串到历史日期。
            Dim usePlcCounters = (logDate >= generatedAt.Date.AddDays(-1))
            Dim morningCut As Integer = If(usePlcCounters, _plc.ReadCutCount(WorkShift.Morning), 0)
            Dim noonCut As Integer = If(usePlcCounters, _plc.ReadCutCount(WorkShift.Noon), 0)
            Dim morningSupport As Integer = If(usePlcCounters, _plc.ReadSupportCount(WorkShift.Morning), 0)
            Dim noonSupport As Integer = If(usePlcCounters, _plc.ReadSupportCount(WorkShift.Noon), 0)
            If morningCut <= 0 Then morningCut = CountShiftCategory(processes, WorkShift.Morning, ProcessCategory.Cutting)
            If noonCut <= 0 Then noonCut = CountShiftCategory(processes, WorkShift.Noon, ProcessCategory.Cutting)
            If morningSupport <= 0 Then morningSupport = CountShiftCategory(processes, WorkShift.Morning, ProcessCategory.Support)
            If noonSupport <= 0 Then noonSupport = CountShiftCategory(processes, WorkShift.Noon, ProcessCategory.Support)

            '--- 进刀/锚护耗时：由工序明细表按时长窗口累计 ---
            Dim morningCutMin = SumCategoryMinutes(processes, WorkShift.Morning, ProcessCategory.Cutting, dayStart, dayEnd)
            Dim noonCutMin = SumCategoryMinutes(processes, WorkShift.Noon, ProcessCategory.Cutting, dayStart, dayEnd)
            Dim morningSupportMin = SumCategoryMinutes(processes, WorkShift.Morning, ProcessCategory.Support, dayStart, dayEnd)
            Dim noonSupportMin = SumCategoryMinutes(processes, WorkShift.Noon, ProcessCategory.Support, dayStart, dayEnd)

            '--- 日进尺：优先 PLC 日进尺变量，缺失用早/中班进尺累加 ---
            Dim advance = If(usePlcCounters, _plc.ReadDailyAdvanceM(), 0)
            If advance <= 0 Then
                advance = _shiftMgr.GetShiftAdvanceM(New ShiftKey(logDate, WorkShift.Morning)) +
                          _shiftMgr.GetShiftAdvanceM(New ShiftKey(logDate, WorkShift.Noon))
            End If

            '--- 故障耗时：按当日窗口裁切累计 ---
            Dim faultMinutes As Double = 0
            For Each ft In faults
                Dim clipStart As Date
                Dim clipEnd As Date
                If ft.ClipTo(dayStart, dayEnd, clipStart, clipEnd) Then
                    faultMinutes += (clipEnd - clipStart).TotalMinutes
                End If
            Next

            Dim summary As New DailySummary With {
                .LogDate = logDate,
                .AdvanceM = advance,
                .MorningCutCount = morningCut,
                .MorningSupportCount = morningSupport,
                .MorningCutMinutes = morningCutMin,
                .MorningSupportMinutes = morningSupportMin,
                .NoonCutCount = noonCut,
                .NoonSupportCount = noonSupport,
                .NoonCutMinutes = noonCutMin,
                .NoonSupportMinutes = noonSupportMin,
                .FaultMinutes = faultMinutes,
                .GeneratedTime = generatedAt
            }
            If processes.Count = 0 AndAlso faults.Count = 0 Then
                summary.Remark = "当日无工序/故障明细"
            End If
            Return summary
        End Function

        ''' <summary>当日故障 = 故障表（按开始日期归属）+ 仍在运行未落表的故障</summary>
        Private Function CollectDayFaults(day As Date) As List(Of FaultRecord)
            Dim list As New List(Of FaultRecord)
            Dim seen As New HashSet(Of String)
            For Each ft In _tables.ReadFaults(day)
                Dim sig = Signature(ft)
                If seen.Add(sig) Then list.Add(ft)
            Next
            For Each ft In _shiftMgr.GetRunningFaultsForDay(day)
                If ft.StartTime >= day.AddDays(1) Then Continue For
                Dim sig = Signature(ft)
                If seen.Add(sig) Then list.Add(ft)
            Next
            list.Sort(AddressOf CompareFault)
            Return list
        End Function

        Private Shared Function Signature(ft As FaultRecord) As String
            Return ft.FaultId.ToString(CultureInfo.InvariantCulture) & "|" & ft.StartTime.ToString("yyyyMMddHHmmss", CultureInfo.InvariantCulture)
        End Function

        Private Shared Function CompareFault(a As FaultRecord, b As FaultRecord) As Integer
            Return Date.Compare(a.StartTime, b.StartTime)
        End Function

        Private Shared Function CountShiftCategory(processes As List(Of ProcessRecord), shift As WorkShift, category As ProcessCategory) As Integer
            Dim count As Integer = 0
            For Each p In processes
                If p.Shift = shift AndAlso p.Category = category Then count += 1
            Next
            Return count
        End Function

        ''' <summary>累计某班次某类工序在 [windowStart, windowEnd) 内的耗时（跨日工序自动裁切）</summary>
        Private Shared Function SumCategoryMinutes(processes As List(Of ProcessRecord), shift As WorkShift, category As ProcessCategory, windowStart As Date, windowEnd As Date) As Double
            Dim total As Double = 0
            For Each p In processes
                If p.Shift <> shift OrElse p.Category <> category Then Continue For
                If Not p.EndTime.HasValue Then Continue For
                Dim s = If(p.StartTime > windowStart, p.StartTime, windowStart)
                Dim e = If(p.EndTime.Value < windowEnd, p.EndTime.Value, windowEnd)
                If e > s Then total += (e - s).TotalMinutes
            Next
            Return total
        End Function

        '==================================================================
        ' 报表生成（字段与甲方"日施工日志"表格一一对应）
        '==================================================================
        Private Function BuildDailyReport(summary As DailySummary) As String
            Dim sb As New StringBuilder
            Dim day = summary.LogDate
            Dim roofBolts = summary.MorningSupportCount * _options.SupportRoofBolts
            Dim baseBolts = summary.MorningSupportCount * _options.SupportSideBolts
            Dim cables = summary.MorningSupportCount * _options.SupportCables
            Dim nRoofBolts = summary.NoonSupportCount * _options.SupportRoofBolts
            Dim nBaseBolts = summary.NoonSupportCount * _options.SupportSideBolts
            Dim nCables = summary.NoonSupportCount * _options.SupportCables

            '锚护耗时按根数比例分摊到三类（5:6:2），保证三类耗时合计等于锚护总耗时
            Dim portion As Double = _options.SupportRoofBolts + _options.SupportSideBolts + _options.SupportCables
            If portion <= 0 Then portion = 1
            Dim mRoofMin, mBaseMin, mCableMin, nRoofMin, nBaseMin, nCableMin As Double
            If _options.SplitSupportDurationByRatio Then
                mRoofMin = summary.MorningSupportMinutes * _options.SupportRoofBolts / portion
                mBaseMin = summary.MorningSupportMinutes * _options.SupportSideBolts / portion
                mCableMin = summary.MorningSupportMinutes * _options.SupportCables / portion
                nRoofMin = summary.NoonSupportMinutes * _options.SupportRoofBolts / portion
                nBaseMin = summary.NoonSupportMinutes * _options.SupportSideBolts / portion
                nCableMin = summary.NoonSupportMinutes * _options.SupportCables / portion
            Else
                '不分摊时只把总数记在顶锚杆行，避免重复累计
                mRoofMin = summary.MorningSupportMinutes
                mBaseMin = 0
                mCableMin = 0
                nRoofMin = summary.NoonSupportMinutes
                nBaseMin = 0
                nCableMin = 0
            End If

            sb.AppendLine("==============================================")
            sb.AppendLine("                日施工日志")
            sb.AppendLine(String.Format("日期：{0:yyyy-MM-dd}                          日进尺：{1:F2} m", day, summary.AdvanceM))
            sb.AppendLine("==============================================")
            sb.AppendLine("【生产情况记录】")
            Dim itemWidths As Integer() = New Integer() {34, 12, 12}
            sb.AppendLine(ReportText.Row(itemWidths, New String() {"施工内容", "数量", "耗时(分钟)"}, True))
            sb.AppendLine("------------------------------------------------------")
            AppendItem(sb, "进刀（早班）", summary.MorningCutCount.ToString(CultureInfo.InvariantCulture), summary.MorningCutMinutes)
            AppendItem(sb, String.Format("顶锚杆支护（早班）({0}根/次)", _options.SupportRoofBolts), roofBolts.ToString(CultureInfo.InvariantCulture), mRoofMin)
            AppendItem(sb, String.Format("顶锚索支护（早班）({0}根/次)", _options.SupportCables), cables.ToString(CultureInfo.InvariantCulture), mCableMin)
            AppendItem(sb, String.Format("帮锚杆支护（早班）({0}根/次)", _options.SupportSideBolts), baseBolts.ToString(CultureInfo.InvariantCulture), mBaseMin)
            AppendItem(sb, "进刀（中班）", summary.NoonCutCount.ToString(CultureInfo.InvariantCulture), summary.NoonCutMinutes)
            AppendItem(sb, String.Format("顶锚杆支护（中班）({0}根/次)", _options.SupportRoofBolts), nRoofBolts.ToString(CultureInfo.InvariantCulture), nRoofMin)
            AppendItem(sb, String.Format("顶锚索支护（中班）({0}根/次)", _options.SupportCables), nCables.ToString(CultureInfo.InvariantCulture), nCableMin)
            AppendItem(sb, String.Format("帮锚杆支护（中班）({0}根/次)", _options.SupportSideBolts), nBaseBolts.ToString(CultureInfo.InvariantCulture), nBaseMin)
            sb.AppendLine("------------------------------------------------------")
            sb.AppendLine(String.Format("合计：进刀 {0} 次；锚护 {1} 次", (summary.MorningCutCount + summary.NoonCutCount).ToString(CultureInfo.InvariantCulture), (summary.MorningSupportCount + summary.NoonSupportCount).ToString(CultureInfo.InvariantCulture)))

            '设备故障（单独建表维护，日日志只做展示）
            sb.AppendLine("")
            sb.AppendLine("【设备故障】")
            Dim faultWidths As Integer() = New Integer() {28, 21, 21, 13}
            sb.AppendLine(ReportText.Row(faultWidths, New String() {"故障ID-描述", "开始时间", "结束时间", "耗时(分钟)"}, True) & "  说明")
            sb.AppendLine("------------------------------------------------------------------------------")
            Dim faults = CollectDayFaults(day)
            Dim dayStart = day.Date
            Dim dayEnd = day.Date.AddDays(1)
            Dim shown As Integer = 0
            For Each ft In faults
                Dim clipStart As Date
                Dim clipEnd As Date
                If Not ft.ClipTo(dayStart, dayEnd, clipStart, clipEnd) Then Continue For
                Dim note As String = ""
                If ft.IsRunning Then note = "未恢复"
                If clipStart > ft.StartTime Then note = (note & " 故障跨日，本日从0点计").Trim()
                If ft.EndTime.HasValue AndAlso clipEnd < ft.EndTime.Value Then note = (note & " 延续至次日，本日裁切").Trim()
                sb.AppendLine(ReportText.Row(faultWidths, New String() {
                    "[" & ft.FaultId.ToString(CultureInfo.InvariantCulture) & "]" & ft.FaultDesc,
                    clipStart.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                    clipEnd.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                    (clipEnd - clipStart).TotalMinutes.ToString("F2", CultureInfo.InvariantCulture)}, True) & note)
                shown += 1
            Next
            If shown = 0 Then sb.AppendLine("（当日无故障记录）")

            '矿方影响、生产问题（现场填写）
            sb.AppendLine("")
            sb.AppendLine("【生产存在问题】")
            sb.AppendLine("（现场填写）")
            sb.AppendLine("")
            sb.AppendLine("【矿方影响】")
            sb.AppendLine("（现场填写）")
            sb.AppendLine("")
            sb.AppendLine("==============================================")
            sb.AppendLine(String.Format("日进尺：{0:F2} m", summary.AdvanceM))
            sb.AppendLine(String.Format("故障累计耗时：{0:F2} 分钟", summary.FaultMinutes))
            If Not String.IsNullOrEmpty(summary.Remark) Then sb.AppendLine("备注：" & summary.Remark)
            sb.AppendLine(String.Format("生成时间：{0:yyyy-MM-dd HH:mm:ss}", summary.GeneratedTime))
            Return sb.ToString()
        End Function

        Private Shared Sub AppendItem(sb As StringBuilder, name As String, count As String, minutes As Double)
            Dim widths As Integer() = New Integer() {34, 12, 12}
            sb.AppendLine(ReportText.Row(widths, New String() {name, count, minutes.ToString("F2", CultureInfo.InvariantCulture)}, True))
        End Sub

    End Class

End Namespace
