﻿Option Explicit On
Option Strict Off
Option Infer On
'==============================================================================
' 文件：LogCommon.vb
' 作用：施工日志公共类型、配置、下位机（PLC）接口定义
' 目标：.NET Framework 4.x / VB.NET（VB11 语法兼容，不依赖 VS2015+ 编译器特性）
'==============================================================================

Imports System
Imports System.Collections.Generic
Imports System.Globalization

Namespace Ebm.ConstructionLog

    ''' <summary>班次</summary>
    Public Enum WorkShift
        ''' <summary>未开班（不属于任何班次的时段）</summary>
        None = 0
        ''' <summary>早班</summary>
        Morning = 1
        ''' <summary>中班</summary>
        Noon = 2
    End Enum

    ''' <summary>工序分类（用于按类统计耗时，不改变工序本身的编码含义）</summary>
    Public Enum ProcessCategory
        ''' <summary>未知/未配置</summary>
        Unknown = 0
        ''' <summary>设备检修</summary>
        Inspection = 1
        ''' <summary>截割/进刀</summary>
        Cutting = 2
        ''' <summary>锚护（锚杆+锚索统一）</summary>
        Support = 3
        ''' <summary>设备移机</summary>
        Relocate = 4
        ''' <summary>其他</summary>
        Other = 5
    End Enum

    ''' <summary>单班次唯一键（日期 + 班次），替代原来的字符串拼接键</summary>
    Public NotInheritable Class ShiftKey
        Implements IEquatable(Of ShiftKey)

        Private ReadOnly _logDate As Date
        Private ReadOnly _shift As WorkShift

        Public Sub New(logDate As Date, shift As WorkShift)
            _logDate = logDate.Date
            _shift = shift
        End Sub

        ''' <summary>日志归属日期（中班跨日时仍为开班当天）</summary>
        Public ReadOnly Property LogDate As Date
            Get
                Return _logDate
            End Get
        End Property

        Public ReadOnly Property Shift As WorkShift
            Get
                Return _shift
            End Get
        End Property

        ''' <summary>缓存/状态文件键，如 20261113_1</summary>
        Public ReadOnly Property CacheKey As String
            Get
                Return _logDate.ToString("yyyyMMdd", CultureInfo.InvariantCulture) & "_" & CInt(_shift).ToString(CultureInfo.InvariantCulture)
            End Get
        End Property

        ''' <summary>日志文件名中的日期，如 261113</summary>
        Public ReadOnly Property ShortDateText As String
            Get
                Return _logDate.ToString("yyMMdd", CultureInfo.InvariantCulture)
            End Get
        End Property

        ''' <summary>班次中文名</summary>
        Public ReadOnly Property ShiftName As String
            Get
                Select Case _shift
                    Case WorkShift.Morning
                        Return "早班"
                    Case WorkShift.Noon
                        Return "中班"
                    Case Else
                        Return "待开班"
                End Select
            End Get
        End Property

        Public Overloads Function Equals(other As ShiftKey) As Boolean Implements IEquatable(Of ShiftKey).Equals
            If other Is Nothing Then Return False
            Return _logDate = other._logDate AndAlso _shift = other._shift
        End Function

        Public Overrides Function Equals(obj As Object) As Boolean
            Return Equals(TryCast(obj, ShiftKey))
        End Function

        Public Overrides Function GetHashCode() As Integer
            Return _logDate.GetHashCode() Xor CInt(_shift)
        End Function

        Public Overrides Function ToString() As String
            Return _logDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) & " " & ShiftName
        End Function
    End Class

    ''' <summary>工序记录实体（工序切换时成对记录开始/结束时间）</summary>
    Public Class ProcessRecord
        Public Property Code As Integer
        Public Property Name As String
        Public Property Category As ProcessCategory = ProcessCategory.Unknown
        ''' <summary>所属班次（从明细表读取时回填，便于日/月统计）</summary>
        Public Property Shift As WorkShift = WorkShift.None
        Public Property StartTime As Date
        ''' <summary>结束时间；Nothing 表示该工序仍在进行</summary>
        Public Property EndTime As Date?

        Public ReadOnly Property IsClosed As Boolean
            Get
                Return EndTime.HasValue
            End Get
        End Property

        ''' <summary>耗时（分钟）＝结束时间－开始时间；未结束记 0，异常负值记 0</summary>
        Public ReadOnly Property DurationMinute As Double
            Get
                If Not EndTime.HasValue Then Return 0
                Dim v = (EndTime.Value - StartTime).TotalMinutes
                If v < 0 Then Return 0
                Return v
            End Get
        End Property


    End Class

    ''' <summary>设备故障记录实体（独立时序，与工序解耦）</summary>
    Public Class FaultRecord
        Public Property FaultId As Integer
        Public Property FaultDesc As String
        ''' <summary>归属班次（从明细表读取时回填）</summary>
        Public Property Shift As WorkShift = WorkShift.None
        Public Property StartTime As Date
        ''' <summary>结束时间；Nothing 表示故障尚未恢复</summary>
        Public Property EndTime As Date?

        Public ReadOnly Property IsRunning As Boolean
            Get
                Return Not EndTime.HasValue
            End Get
        End Property

        ''' <summary>故障持续时长（分钟）</summary>
        Public ReadOnly Property DurationMinute As Double
            Get
                If Not EndTime.HasValue Then Return 0
                Dim v = (EndTime.Value - StartTime).TotalMinutes
                If v < 0 Then Return 0
                Return v
            End Get
        End Property

        ''' <summary>
        ''' 取该故障与指定时间窗 [from, to] 的重叠区间。
        ''' 用于跨班次故障在各自班次日志中按实际重叠时长展示，避免污染原始起止时间。
        ''' </summary>
        Public Function ClipTo(fromTime As Date, toTime As Date, ByRef clipStart As Date, ByRef clipEnd As Date) As Boolean
            Dim s = If(StartTime > fromTime, StartTime, fromTime)
            Dim e = If(EndTime.HasValue, If(EndTime.Value < toTime, EndTime.Value, toTime), toTime)
            If e <= s Then Return False
            clipStart = s
            clipEnd = e
            Return True
        End Function


    End Class

    ''' <summary>单个班次的完整运行状态（掉电可由状态文件恢复，不依赖进程内存）</summary>
    Public Class ShiftSnapshot
        Public Property Key As ShiftKey
        Public Property AdvanceM As System.Double = 0
        Public Property ProcessList As New List(Of ProcessRecord)
        Public Property FaultList As New List(Of FaultRecord)
        Public Property OilPump1Run As Boolean = False
        Public Property OilPump2Run As Boolean = False
        ''' <summary>本班次油泵是否启动过（中班"泵启则记录泵停时间"的收尾依据）</summary>
        Public Property PumpEverStarted As Boolean = False
        ''' <summary>油泵停止时刻候选（去抖用：确认未重启后才作为中班结束时间）</summary>
        Public Property PumpStopCandidate As Date?
        ''' <summary>本班次最后一次收到的工序编码（做工序切换边沿检测；0=无/停机）</summary>
        Public Property LastProcessCode As Integer = 0
        ''' <summary>本班次第一次送电时间（需求：第一次写入时间为设备第一次送电时间）</summary>
        Public Property PowerOnTime As Date?
        ''' <summary>班次实际开始时间（第一条工序/故障/送电的较小值）</summary>
        Public Property StartTime As Date?
        ''' <summary>班次实际结束时间（收尾时确定）</summary>
        Public Property EndTime As Date?
        Public Property IsClosed As Boolean = False
        ''' <summary>上次写日志文件的时间，用于刷新节流</summary>
        Public Property LastFlushTime As Date = Date.MinValue

        Public ReadOnly Property HasData As Boolean
            Get
                Return ProcessList.Count > 0 OrElse FaultList.Count > 0 OrElse AdvanceM <> 0 OrElse PowerOnTime.HasValue
            End Get
        End Property

        ''' <summary>当前未结束工序（正常情况下最多一条）</summary>
        Public ReadOnly Property OpenProcess As ProcessRecord
            Get
                For i As Integer = ProcessList.Count - 1 To 0 Step -1
                    If Not ProcessList(i).IsClosed Then Return ProcessList(i)
                Next
                Return Nothing
            End Get
        End Property

        Public Function FindRunningFault(faultId As Integer) As FaultRecord
            For i As Integer = FaultList.Count - 1 To 0 Step -1
                If FaultList(i).FaultId = faultId AndAlso FaultList(i).IsRunning Then Return FaultList(i)
            Next
            Return Nothing
        End Function


    End Class

    ''' <summary>工序定义（编码 → 名称 + 分类）</summary>
    Public Class ProcessDefinition
        Public Property Code As Integer
        Public Property Name As String
        Public Property Category As ProcessCategory = ProcessCategory.Unknown
    End Class

    ''' <summary>故障定义（编码 → 名称 + 是否影响生产）</summary>
    Public Class FaultDefinition
        Public Property Code As Integer
        Public Property Name As String
        ''' <summary>是否属于"影响生产、需要统计"的故障（需求：具体范围待电气分院与主机院商定）</summary>
        Public Property IsProductionAffecting As Boolean = True
    End Class

    ''' <summary>日志参数配置（班次边界、锚护折算系数、刷新节流等，现场可调）</summary>
    Public Class LogOptions
        ''' <summary>日志根目录</summary>
        Public Property LogRootPath As String = "D:\EbmLogs"
        ''' <summary>早班开始小时（含）</summary>
        Public Property MorningStartHour As Integer = 8
        ''' <summary>早班结束小时（不含），即中班开始小时</summary>
        Public Property MorningEndHour As Integer = 16
        ''' <summary>中班开始小时（含）</summary>
        Public Property NoonStartHour As Integer = 16

        ''' <summary>中班是否以"油泵停"为结束条件（需求：中班最末工序结束时间为中班结束时间，泵启则记录泵停时间）</summary>
        Public Property NoonEndByPumpStop As Boolean = True
        ''' <summary>中班跨日延续上限（小时）：超过次日该时刻仍未停泵则强制收尾，避免无限挂起</summary>
        Public Property NoonMaxCarryOverHours As Integer = 8
        ''' <summary>泵停去抖（秒）：泵停后若在此时长内重启则取消收尾，避免油泵抖动误结束中班；0=立即收尾</summary>
        Public Property NoonPumpStopDebounceSeconds As Integer = 120
        ''' <summary>日志文件刷新节流（秒），避免每次进尺采样都重写文件</summary>
        Public Property ReportRefreshSeconds As Integer = 30
        ''' <summary>一个锚护工序折算的顶锚杆根数</summary>
        Public Property SupportRoofBolts As Integer = 5
        ''' <summary>一个锚护工序折算的帮锚杆根数</summary>
        Public Property SupportSideBolts As Integer = 6
        ''' <summary>一个锚护工序折算的锚索根数</summary>
        Public Property SupportCables As Integer = 2
        ''' <summary>日日志中锚护耗时是否按根数比例分摊到三类（否则只挂总数）</summary>
        Public Property SplitSupportDurationByRatio As Boolean = True
        ''' <summary>是否只统计"影响生产"的故障</summary>
        Public Property OnlyCountProductionFaults As Boolean = False
        ''' <summary>文本编码（现场电脑默认 GB18030，兼容记事本/Excel 打开）</summary>
        Public Property TextEncodingName As String = "GB18030"
        ''' <summary>文件写入失败重试次数</summary>
        Public Property IoRetryCount As Integer = 3
        ''' <summary>文件写入失败重试间隔（毫秒）</summary>
        Public Property IoRetryDelayMs As Integer = 50
    End Class

    ''' <summary>工序/故障配置表 + 运行参数</summary>
    Public Class LogConfig
        Public Property Options As New LogOptions
        Public Property ProcessMap As New Dictionary(Of Integer, ProcessDefinition)
        Public Property FaultMap As New Dictionary(Of Integer, FaultDefinition)

        Public Sub New()
            InitProcessMap()
            InitFaultMap()
        End Sub

        ''' <summary>内置工序编码表（保持与原下位机编码一致：-1 检修，0 无，1~9 截割位置，10 锚护，11 移机）</summary>
        Private Sub InitProcessMap()
            AddProcess(-1, "设备检修", ProcessCategory.Inspection)
            AddProcess(0, "无", ProcessCategory.Unknown)
            AddProcess(1, "上部左侧", ProcessCategory.Cutting)
            AddProcess(2, "上部中间", ProcessCategory.Cutting)
            AddProcess(3, "上部右侧", ProcessCategory.Cutting)
            AddProcess(4, "中部左侧", ProcessCategory.Cutting)
            AddProcess(5, "中部中间", ProcessCategory.Cutting)
            AddProcess(6, "中部右侧", ProcessCategory.Cutting)
            AddProcess(7, "下部左侧", ProcessCategory.Cutting)
            AddProcess(8, "下部中间", ProcessCategory.Cutting)
            AddProcess(9, "下部右侧", ProcessCategory.Cutting)
            '需求：锚杆、锚索统一为"锚护"工序
            AddProcess(10, "锚护", ProcessCategory.Support)
            AddProcess(11, "设备移机", ProcessCategory.Relocate)
        End Sub

        Private Sub AddProcess(code As Integer, name As String, category As ProcessCategory)
            ProcessMap(code) = New ProcessDefinition With {.Code = code, .Name = name, .Category = category}
        End Sub

        ''' <summary>内置 52 条故障编码表（与原代码一致）</summary>
        Private Sub InitFaultMap()
            Dim items As String() = New String() {
                "急停异常", "相序异常", "127V绝缘异常", "220V绝缘异常", "过压异常", "欠压异常",
                "电压传感器异常", "遥控器连接异常", "遥控急停", "绝缘检测模块异常", "电机温度模块丢失",
                "绝缘检测未完成", "油泵1互感器丢失", "油泵1过载", "油泵1速断", "油泵1三相不平衡",
                "油泵1缺相", "油泵1温度传感器异常", "油泵1超温", "油泵1漏电闭锁", "油泵1黏连异常",
                "油泵1电流丢失", "油泵1电机急停", "油泵2互感器丢失", "油泵2过载", "油泵2速断",
                "油泵2三相不平衡", "油泵2缺相", "油泵2温度传感器异常", "油泵2超温", "油泵2漏电闭锁",
                "油泵2黏连异常", "油泵2电流丢失", "油泵2电机急停", "运水压力传感器报警",
                "运水压力传感器故障", "刀盘系统补油压力传感器报警", "刀盘系统补油压力传感器故障",
                "主驱动散热齿轮油流量传感器报警", "主驱动散热齿轮油流量传感器故障",
                "主驱动散热齿轮油温度传感器报警", "主驱动散热齿轮油温度传感器故障",
                "主驱动散热齿轮油液位传感器报警", "主驱动散热齿轮油液位传感器故障",
                "左前地撑位移传感器故障", "右前地撑位移传感器故障", "左前顶撑位移传感器故障",
                "右前顶撑位移传感器故障", "左后顶撑位移传感器故障", "右后顶撑位移传感器故障",
                "左后地撑位移传感器故障", "右后地撑位移传感器故障"
            }
            For i As Integer = 0 To items.Length - 1
                'ID 从 1 开始，与现场故障字位对应
                FaultMap(i + 1) = New FaultDefinition With {.Code = i + 1, .Name = items(i), .IsProductionAffecting = True}
            Next
        End Sub

        ''' <summary>查询工序定义，未配置时返回"未知工序"定义（不抛异常，不丢事件）</summary>
        Public Function GetProcess(code As Integer) As ProcessDefinition
            Dim def As ProcessDefinition = Nothing
            If ProcessMap.TryGetValue(code, def) Then Return def
            Return New ProcessDefinition With {.Code = code, .Name = "未知工序【编码:" & code.ToString(CultureInfo.InvariantCulture) & "】", .Category = ProcessCategory.Unknown}
        End Function

        ''' <summary>查询故障定义，未配置时返回"未知故障"定义</summary>
        Public Function GetFault(code As Integer) As FaultDefinition
            Dim def As FaultDefinition = Nothing
            If FaultMap.TryGetValue(code, def) Then Return def
            Return New FaultDefinition With {.Code = code, .Name = "未知故障【ID:" & code.ToString(CultureInfo.InvariantCulture) & "】", .IsProductionAffecting = True}
        End Function

        ''' <summary>该故障是否应写入/统计（仅生产影响故障时可过滤）</summary>
        Public Function ShouldRecordFault(code As Integer) As Boolean
            If Not Options.OnlyCountProductionFaults Then Return True
            Return GetFault(code).IsProductionAffecting
        End Function

        ''' <summary>根据时间判断班次（跨日 0~8 点归前一日中班，由上层再判断该班是否已收尾）</summary>
        Public Function ResolveShift(nowTime As Date) As ShiftKey
            Dim h = nowTime.Hour
            If h >= Options.MorningStartHour AndAlso h < Options.MorningEndHour Then
                Return New ShiftKey(nowTime.Date, WorkShift.Morning)
            End If
            If h >= Options.NoonStartHour Then
                Return New ShiftKey(nowTime.Date, WorkShift.Noon)
            End If
            If h < Options.MorningStartHour Then
                '0 点 ~ 次日早班开始前：可能仍是前一日的跨日中班
                Return New ShiftKey(nowTime.Date.AddDays(-1), WorkShift.Noon)
            End If
            '早班结束与中班开始之间的空档（配置非连续班次时）：待开班
            Return New ShiftKey(nowTime.Date, WorkShift.None)
        End Function

        ''' <summary>班次固定边界：早班结束 = 16:00，中班固定结束 = 次日 00:00</summary>
        Public Function GetShiftFixedEnd(key As ShiftKey) As Date
            If key.Shift = WorkShift.Morning Then
                Return key.LogDate.AddHours(Options.MorningEndHour)
            End If
            Return key.LogDate.AddDays(1)
        End Function

        ''' <summary>班次固定开始时间</summary>
        Public Function GetShiftFixedStart(key As ShiftKey) As Date
            If key.Shift = WorkShift.Morning Then
                Return key.LogDate.AddHours(Options.MorningStartHour)
            End If
            If key.Shift = WorkShift.Noon Then
                Return key.LogDate.AddHours(Options.NoonStartHour)
            End If
            '待开班（仅用于承载待开班时段的故障记录，不产生班日志）
            Return key.LogDate
        End Function

        ''' <summary>该班次是否需要生成班施工日志文件（待开班不需要）</summary>
        Public Function IsReportableShift(key As ShiftKey) As Boolean
            Return key.Shift = WorkShift.Morning OrElse key.Shift = WorkShift.Noon
        End Function
    End Class

    ''' <summary>
    ''' 下位机（PLC）交互接口：掉电保存变量读取 + 完成标志位下发。
    ''' 说明：具体字段/地址以下位机协议表为准（需求中"下位机协议表"为待确认项），
    ''' 本项目只依赖此接口，现场实现时替换为实际 CAN/Modbus 读写即可。
    ''' </summary>
    Public Interface IPlcIo
        ''' <summary>读取当前班次进尺（单位：米，与日志报表一致；下位机若为 mm 请在此适配层换算）</summary>
        Function ReadShiftAdvanceM() As Double
        ''' <summary>读取当日进尺（单位：米；无此变量时返回 0 由上层用班进尺累加）</summary>
        Function ReadDailyAdvanceM() As Double
        ''' <summary>读取指定班次进刀（截割）工序次数（下位机掉电保存变量）</summary>
        Function ReadCutCount(shift As WorkShift) As Integer
        ''' <summary>读取指定班次锚护工序次数（下位机掉电保存变量）</summary>
        Function ReadSupportCount(shift As WorkShift) As Integer
        ''' <summary>下发班次日志生成完成标志（早班完成后 PLC 切换记录；中班完成后 PLC 归零工序）</summary>
        Sub WriteShiftLogDoneFlag(shift As WorkShift, value As Boolean)
        ''' <summary>下发日施工日志生成完成标志</summary>
        Sub WriteDailyLogDoneFlag(value As Boolean)
        ''' <summary>下发工序归零命令（中班日志生成完成后执行）</summary>
        Sub RequestProcessReset()
    End Interface

    ''' <summary>空实现：没有接入下位机时（仿真/调试）使用，所有读为 0、写为空操作</summary>
    Public Class NullPlcIo
        Implements IPlcIo

        Public Function ReadShiftAdvanceM() As Double Implements IPlcIo.ReadShiftAdvanceM
            Return 0
        End Function

        Public Function ReadDailyAdvanceM() As Double Implements IPlcIo.ReadDailyAdvanceM
            Return 0
        End Function

        Public Function ReadCutCount(shift As WorkShift) As Integer Implements IPlcIo.ReadCutCount
            Return 0
        End Function

        Public Function ReadSupportCount(shift As WorkShift) As Integer Implements IPlcIo.ReadSupportCount
            Return 0
        End Function

        Public Sub WriteShiftLogDoneFlag(shift As WorkShift, value As Boolean) Implements IPlcIo.WriteShiftLogDoneFlag
        End Sub

        Public Sub WriteDailyLogDoneFlag(value As Boolean) Implements IPlcIo.WriteDailyLogDoneFlag
        End Sub

        Public Sub RequestProcessReset() Implements IPlcIo.RequestProcessReset
        End Sub
    End Class

End Namespace
