﻿Option Explicit On
Option Strict Off
Option Infer On
'==============================================================================
' 文件：MonthlyLogManager.vb
' 作用：月施工日志生成（按月记录每日进尺，考虑跨月数据存储）
'
' 需求对应：
'   1) 日志命名：月施工日志-日期（yyMM）；
'   2) 按月记录每日进尺；
'   3) 跨月数据存储：日汇总表按日期存储，月日志按日期所属月份聚合，
'      月末/月初自动写入各自月份文件，互不覆盖。
'==============================================================================

Imports System
Imports System.Collections.Generic
Imports System.Globalization
Imports System.Text

Namespace Ebm.ConstructionLog

    ''' <summary>月施工日志管理器（线程安全，数据源为日汇总表）</summary>
    Public Class MonthlyLogManager
        Private ReadOnly _config As LogConfig
        Private ReadOnly _options As LogOptions
        Private ReadOnly _fs As LogFileSystem
        Private ReadOnly _paths As LogPaths
        Private ReadOnly _tables As RecordTables
        Private ReadOnly _gate As New Object()

        Public Sub New(config As LogConfig, fs As LogFileSystem, paths As LogPaths, tables As RecordTables)
            _config = config
            _options = config.Options
            _fs = fs
            _paths = paths
            _tables = tables
        End Sub

        ''' <summary>按某日所属月份重算并写出月施工日志（跨月时各月文件互不影响）</summary>
        Public Function UpdateMonth(day As Date) As Double
            SyncLock _gate
                Dim month = New Date(day.Year, day.Month, 1)
                Dim summaries = _tables.ReadDailySummaries(month)
                Dim text = BuildMonthReport(month, summaries)
                _fs.WriteAllTextAtomic(_paths.MonthlyLogFile(month), text)
                Return GetMonthAdvance(summaries)
            End SyncLock
        End Function

        ''' <summary>读取某月已生成日汇总的进尺合计（米）</summary>
        Public Function GetMonthAdvance(month As Date) As Double
            Return GetMonthAdvance(_tables.ReadDailySummaries(New Date(month.Year, month.Month, 1)))
        End Function

        Private Shared Function GetMonthAdvance(summaries As List(Of DailySummary)) As Double
            Dim total As Double = 0
            For Each item In summaries
                total += item.AdvanceM
            Next
            Return total
        End Function

        Private Function BuildMonthReport(month As Date, summaries As List(Of DailySummary)) As String
            Dim byDay As New Dictionary(Of Integer, DailySummary)
            For Each item In summaries
                byDay(item.LogDate.Day) = item
            Next

            Dim sb As New StringBuilder
            Dim total As Double = GetMonthAdvance(summaries)
            Dim daysInMonth = Date.DaysInMonth(month.Year, month.Month)

            sb.AppendLine("==============================================")
            sb.AppendLine("                月施工日志")
            sb.AppendLine(String.Format("月份：{0:yyyy-MM}                        月进尺：{1:F2} m", month, total))
            sb.AppendLine("==============================================")
            sb.AppendLine("【生产情况记录】")
            Dim dayWidths As Integer() = New Integer() {10, 14}
            sb.AppendLine(ReportText.Row(dayWidths, New String() {"日期", "进尺(m)"}, True) & "  备注")
            sb.AppendLine("----------------------------------------------")
            For d As Integer = 1 To daysInMonth
                Dim item As DailySummary = Nothing
                Dim advText As String = ""
                Dim remark As String = ""
                If byDay.TryGetValue(d, item) Then
                    advText = item.AdvanceM.ToString("F2", CultureInfo.InvariantCulture)
                    remark = item.Remark
                End If
                sb.AppendLine(ReportText.Row(dayWidths, New String() {d.ToString(CultureInfo.InvariantCulture) & "日", advText}, True) & remark)
            Next
            sb.AppendLine("----------------------------------------------")
            sb.AppendLine(String.Format("本月合计：{0:F2} m（计 {1} 天有数据）", total, summaries.Count.ToString(CultureInfo.InvariantCulture)))
            sb.AppendLine("")
            sb.AppendLine("==============================================")
            sb.AppendLine(String.Format("生成时间：{0:yyyy-MM-dd HH:mm:ss}", Date.Now))
            Return sb.ToString()
        End Function

    End Class

End Namespace
