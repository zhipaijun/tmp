﻿Option Explicit On
Option Strict Off
Option Infer On
'==============================================================================
' 文件：Program.vb
' 作用：控制台自测 + 现场演示程序
'   在不接 PLC 的情况下，用模拟时钟/模拟下位机完整跑一遍：
'     - 早班工序切换、16:00 收尾、进尺、锚护折算；
'     - 中班泵启/泵停收尾（结束时间取泵停时间）；
'     - 跨班故障裁切；
'     - 跨日第一次送电生成上一日日施工日志 + 月施工日志；
'     - 断电重启后状态恢复、不重复记录；
'     - 跨月（11/30 → 12/1）数据分别落月；
'     - 待开班时段不生成非法"待开班"日志。
'   运行：EbmConstructionLog.exe   退出码 0=全部通过，1=有失败
'==============================================================================

Imports System
Imports System.Collections.Generic
Imports System.Globalization
Imports System.IO
Imports System.Text

Namespace Ebm.ConstructionLog.Sim

    ''' <summary>模拟下位机：实现 IPlcIo，并记录下发标志顺序，便于断言握手逻辑</summary>
    Friend Class SimulatedPlc
        Implements IPlcIo

        Public Property ShiftAdvanceM As Double = 0
        Public Property DailyAdvanceM As Double = 0
        Private ReadOnly _cutCounts As New Dictionary(Of WorkShift, Integer)
        Private ReadOnly _supportCounts As New Dictionary(Of WorkShift, Integer)
        Private ReadOnly _shiftFlags As New Dictionary(Of WorkShift, Boolean)
        Public ReadOnly Calls As New List(Of String)

        Public Function GetCut(shift As WorkShift) As Integer
            Dim v As Integer = 0
            _cutCounts.TryGetValue(shift, v)
            Return v
        End Function

        Public Sub SetCut(shift As WorkShift, value As Integer)
            _cutCounts(shift) = value
        End Sub

        Public Function GetSupport(shift As WorkShift) As Integer
            Dim v As Integer = 0
            _supportCounts.TryGetValue(shift, v)
            Return v
        End Function

        Public Sub SetSupport(shift As WorkShift, value As Integer)
            _supportCounts(shift) = value
        End Sub

        Public Function GetShiftFlag(shift As WorkShift) As Boolean
            Dim v As Boolean = False
            _shiftFlags.TryGetValue(shift, v)
            Return v
        End Function

        Public Function ReadShiftAdvanceM() As Double Implements IPlcIo.ReadShiftAdvanceM
            Return ShiftAdvanceM
        End Function

        Public Function ReadDailyAdvanceM() As Double Implements IPlcIo.ReadDailyAdvanceM
            Return DailyAdvanceM
        End Function

        Public Function ReadCutCount(shift As WorkShift) As Integer Implements IPlcIo.ReadCutCount
            Return GetCut(shift)
        End Function

        Public Function ReadSupportCount(shift As WorkShift) As Integer Implements IPlcIo.ReadSupportCount
            Return GetSupport(shift)
        End Function

        Public Sub WriteShiftLogDoneFlag(shift As WorkShift, value As Boolean) Implements IPlcIo.WriteShiftLogDoneFlag
            _shiftFlags(shift) = value
            Calls.Add("shiftFlag:" & shift.ToString() & "=" & value.ToString())
        End Sub

        Public Sub WriteDailyLogDoneFlag(value As Boolean) Implements IPlcIo.WriteDailyLogDoneFlag
            Calls.Add("dailyFlag=" & value.ToString())
        End Sub

        Public Sub RequestProcessReset() Implements IPlcIo.RequestProcessReset
            Calls.Add("processReset")
        End Sub
    End Class

    ''' <summary>断言收集器</summary>
    Friend Class TestRunner
        Private ReadOnly _failures As New List(Of String)
        Public Property PassedCount As Integer = 0

        Public ReadOnly Property Failures As List(Of String)
            Get
                Return _failures
            End Get
        End Property

        Public Sub Check(name As String, condition As Boolean)
            If condition Then
                PassedCount += 1
            Else
                _failures.Add(name)
                Console.WriteLine("  [FAIL] " & name)
            End If
        End Sub

        Public Sub CheckContains(name As String, text As String, token As String)
            Check(name & "（应包含：" & token & "）", text IsNot Nothing AndAlso text.Contains(token))
        End Sub

        Public Sub CheckNotContains(name As String, text As String, token As String)
            Check(name & "（不应包含：" & token & "）", text Is Nothing OrElse Not text.Contains(token))
        End Sub
    End Class

    ''' <summary>测试夹具：独立日志根目录 + 服务实例</summary>
    Friend Class Fixture
        Public ReadOnly Root As String
        Public ReadOnly Config As LogConfig
        Public ReadOnly Plc As New SimulatedPlc()
        Private _service As ConstructionLogService

        Public ReadOnly Property Service As ConstructionLogService
            Get
                Return _service
            End Get
        End Property

        Public Sub New(baseDir As String, name As String)
            Root = Path.Combine(baseDir, name)
            If Directory.Exists(Root) Then Directory.Delete(Root, True)
            Config = New LogConfig()
            Config.Options.LogRootPath = Root
            Config.Options.IoRetryCount = 1
            Config.Options.IoRetryDelayMs = 10
            _service = New ConstructionLogService(Config, Plc)
        End Sub

        ''' <summary>模拟上位机重启：保留日志/状态文件，重建服务实例</summary>
        Public Sub Reopen()
            _service = New ConstructionLogService(Config, Plc)
        End Sub

        Public Function LogPath(fileName As String) As String
            Return Path.Combine(Root, "Logs", fileName)
        End Function

        Public Function DataPath(fileName As String) As String
            Return Path.Combine(Root, "Data", fileName)
        End Function

        Public Function Exists(fileName As String) As Boolean
            Return File.Exists(LogPath(fileName))
        End Function

        Public Function ReadLog(fileName As String) As String
            Dim p = LogPath(fileName)
            If Not File.Exists(p) Then Return ""
            Return File.ReadAllText(p, Encoding.GetEncoding("GB18030"))
        End Function

        Public Function ReadData(fileName As String) As String
            Dim p = DataPath(fileName)
            If Not File.Exists(p) Then Return ""
            Return File.ReadAllText(p, Encoding.GetEncoding("GB18030"))
        End Function

        Public Function LogFileNames() As String()
            Dim dir = Path.Combine(Root, "Logs")
            If Not Directory.Exists(dir) Then Return New String() {}
            Return Directory.GetFiles(dir)
        End Function
    End Class

    Friend Module Program

        Private ReadOnly BaseDir As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "demo")

        Public Function Main(args As String()) As Integer
            Try
                Console.OutputEncoding = New UTF8Encoding(False)
            Catch ex As Exception
                '部分控制台不支持切换编码，忽略
            End Try

            If Directory.Exists(BaseDir) Then Directory.Delete(BaseDir, True)
            Directory.CreateDirectory(BaseDir)

            Dim runner As New TestRunner()
            Console.WriteLine("================ EBM 施工日志优化版 自测开始 ================")

            Console.WriteLine("[场景1] 早班/中班/日/月全流程")
            RunScenarioFullDay(runner)

            Console.WriteLine("[场景2] 故障跨班裁切 + 故障单独建表")
            RunScenarioCrossShiftFault(runner)

            Console.WriteLine("[场景3] 断电重启恢复 + 不重复记录")
            RunScenarioRestart(runner)

            Console.WriteLine("[场景4] 跨月数据分别落月")
            RunScenarioCrossMonth(runner)

            Console.WriteLine("[场景5] 待开班时段不生成非法日志")
            RunScenarioWaitShift(runner)

            Console.WriteLine("[场景6] 中班跨日泵停收尾（泵停时间作为中班结束时间）")
            RunScenarioNoonCrossDay(runner)

            Console.WriteLine("[场景7] 配置文件驱动班次/锚护系数/故障过滤/工序改名")
            RunScenarioConfigFile(runner)

            Console.WriteLine("[场景8] 油泵抖动去抖（泵停后重启不误结束中班）")
            RunScenarioPumpDebounce(runner)

            Console.WriteLine("[场景9] 评审探针回归：关闭泵停收尾/提前生成拒绝/时钟回拨/跨日重启补日日志")
            RunScenarioRegression(runner)

            Console.WriteLine("============================================================")
            If runner.Failures.Count = 0 Then
                Console.WriteLine("全部通过：共 " & runner.PassedCount.ToString(CultureInfo.InvariantCulture) & " 项断言")
                Console.WriteLine("演示日志目录：" & BaseDir)
                Return 0
            Else
                Console.WriteLine("失败 " & runner.Failures.Count.ToString(CultureInfo.InvariantCulture) & " 项 / 通过 " & runner.PassedCount.ToString(CultureInfo.InvariantCulture) & " 项")
                For Each item In runner.Failures
                    Console.WriteLine("  - " & item)
                Next
                Return 1
            End If
        End Function

        '==================================================================
        ' 场景1：一个完整班次日（早班 + 中班 + 次日生成日/月日志）
        '==================================================================
        Private Sub RunScenarioFullDay(runner As TestRunner)
            Dim f As New Fixture(BaseDir, "s1_full_day")
            Dim svc = f.Service
            Dim plc = f.Plc

            '----- 早班 -----
            svc.OnPowerOn(New Date(2026, 11, 13, 7, 50, 0))   '早班前送电（待开班），第一个工序仍应从班次开始时刻起算
            svc.UpdateProcessInfo(New Date(2026, 11, 13, 8, 0, 5), -1, 0)          '设备检修
            svc.UpdateProcessInfo(New Date(2026, 11, 13, 8, 30, 0), 1, 1.2)        '上部左侧（截割）
            svc.UpdateProcessInfo(New Date(2026, 11, 13, 9, 15, 0), 10, 2.0)       '锚护
            svc.UpdateProcessInfo(New Date(2026, 11, 13, 9, 40, 0), 0, 2.2)        '停机
            svc.UpdateProcessInfo(New Date(2026, 11, 13, 9, 50, 0), 2, 2.6)        '上部中间
            svc.UpdateProcessInfo(New Date(2026, 11, 13, 12, 0, 0), 10, 7.5)       '锚护
            svc.UpdateProcessInfo(New Date(2026, 11, 13, 12, 20, 0), 11, 7.8)      '设备移机
            svc.UpdateProcessInfo(New Date(2026, 11, 13, 12, 50, 0), 0, 8.0)
            svc.UpdateProcessInfo(New Date(2026, 11, 13, 15, 30, 0), 5, 12.0)      '第五刀位置
            svc.Tick(New Date(2026, 11, 13, 16, 0, 1))                              '16:00 早班收尾

            Dim morningFile = "班施工日志-261113-早班.txt"
            Dim morningText = f.ReadLog(morningFile)
            runner.Check("早班日志文件已生成", f.Exists(morningFile))
            runner.CheckContains("早班日志含当班进尺", morningText, "当班进尺：12.00 m")
            runner.CheckContains("早班日志班次结束时间为16:00", morningText, "班次结束时间：2026-11-13 16:00:00")
            runner.CheckContains("早班日志含设备检修", morningText, "设备检修")
            runner.CheckContains("早班日志含第一次送电时间", morningText, "2026-11-13 08:00:00")
            runner.CheckContains("早班日志锚护折算2次", morningText, "锚护工序次数：2 次")
            runner.CheckContains("早班日志锚护折算顶锚杆10根", morningText, "顶锚杆：10 根")
            runner.CheckNotContains("工序明细表不应出现工序0（无）行", f.ReadData("process_records.tsv"), "|无|")
            runner.Check("早班收尾下发早班完成标志", plc.GetShiftFlag(WorkShift.Morning))
            runner.Check("早班收尾后日志文件未被占用", CanOpenExclusive(f.LogPath(morningFile)))

            '模拟下位机掉电保存计数
            plc.SetCut(WorkShift.Morning, 3)
            plc.SetSupport(WorkShift.Morning, 2)

            '----- 中班（16:00 接班，泵启后泵停收尾）-----
            svc.UpdateProcessInfo(New Date(2026, 11, 13, 16, 0, 2), 1, 0)          '中班第一工序
            svc.CheckOilMtrStatus(New Date(2026, 11, 13, 16, 20, 0), True, False)  '油泵启动
            svc.UpdateProcessInfo(New Date(2026, 11, 13, 17, 0, 0), 10, 3.0)       '锚护
            svc.UpdateProcessInfo(New Date(2026, 11, 13, 18, 0, 0), 0, 3.2)
            svc.UpdateProcessInfo(New Date(2026, 11, 13, 21, 0, 0), 2, 8.5)        '上部中间
            svc.CheckOilMtrStatus(New Date(2026, 11, 13, 23, 10, 0), False, False) '泵停 → 中班结束候选
            svc.Tick(New Date(2026, 11, 13, 23, 12, 1))                           '默认去抖120s后确认泵停收尾

            Dim noonFile = "班施工日志-261113-中班.txt"
            Dim noonText = f.ReadLog(noonFile)
            runner.Check("中班日志文件已生成", f.Exists(noonFile))
            runner.CheckContains("中班日志班次结束时间取泵停时间", noonText, "班次结束时间：2026-11-13 23:10:00")
            runner.CheckContains("中班日志锚护折算1次", noonText, "锚护工序次数：1 次")
            runner.CheckContains("中班日志当班进尺", noonText, "当班进尺：8.50 m")
            runner.Check("中班收尾下发中班完成标志", plc.GetShiftFlag(WorkShift.Noon))
            runner.Check("中班收尾下发工序归零", plc.Calls.Contains("processReset"))
            runner.Check("中班日志文件未被占用", CanOpenExclusive(f.LogPath(noonFile)))

            plc.SetCut(WorkShift.Noon, 2)
            plc.SetSupport(WorkShift.Noon, 1)
            plc.DailyAdvanceM = 20.5
            svc.CheckOilMtrStatus(New Date(2026, 11, 13, 23, 20, 0), False, False)  '泵已停，不应重复收尾

            '----- 次日 2:00 第一次送电 → 生成上一日日/月日志 -----
            plc.ShiftAdvanceM = 0
            svc.OnPowerOn(New Date(2026, 11, 14, 2, 0, 0))

            Dim dailyFile = "日施工日志-261113.txt"
            Dim dailyText = f.ReadLog(dailyFile)
            runner.Check("日施工日志已生成", f.Exists(dailyFile))
            runner.CheckContains("日日志日进尺", dailyText, "日进尺：20.50 m")
            runner.CheckContains("日日志进刀/锚护合计", dailyText, "合计：进刀 5 次；锚护 3 次")
            runner.CheckContains("日日志含顶锚杆支护行", dailyText, "顶锚杆支护（早班）")
            runner.CheckContains("日日志含中班进刀行", dailyText, "进刀（中班）")
            runner.Check("日日志生成后下发日完成标志", plc.Calls.Contains("dailyFlag=True"))
            runner.Check("日日志生成后清零班次标志", plc.Calls.Contains("shiftFlag:Morning=False"))
            runner.Check("日日志生成后日标志清零（脉冲）", plc.Calls.Contains("dailyFlag=False"))

            Dim monthlyFile = "月施工日志-2611.txt"
            Dim monthlyText = f.ReadLog(monthlyFile)
            runner.Check("月施工日志已生成", f.Exists(monthlyFile))
            runner.CheckContains("月日志含13日进尺", monthlyText, "13日")
            runner.CheckContains("月日志含13日数值", monthlyText, "20.50")

            '日汇总表核对（单独建表累计）
            Dim summaryRow = FindRow(f.ReadData("daily_summary.tsv"), "20261113")
            runner.Check("日汇总表有当日记录", summaryRow IsNot Nothing)
            If summaryRow IsNot Nothing Then
                Dim p = summaryRow.Split(New Char() {"|"c})
                runner.Check("日汇总表进尺=20.50", p.Length >= 11 AndAlso p(1) = "20.50")
                runner.Check("日汇总表早班进刀=3", p.Length >= 11 AndAlso p(2) = "3")
                runner.Check("日汇总表早班锚护=2", p.Length >= 11 AndAlso p(3) = "2")
                runner.Check("日汇总表早班截割耗时=205.00", p.Length >= 11 AndAlso p(4) = "205.00")
                runner.Check("日汇总表早班锚护耗时=45.00", p.Length >= 11 AndAlso p(5) = "45.00")
                runner.Check("日汇总表中班进刀=2", p.Length >= 11 AndAlso p(6) = "2")
                runner.Check("日汇总表中班锚护=1", p.Length >= 11 AndAlso p(7) = "1")
            End If

            '工序明细表：早班 7 条 + 中班 3 条
            Dim processRows = CountRows(f.ReadData("process_records.tsv"), "20261113")
            runner.Check("工序明细表记录数=10（实际 " & processRows.ToString(CultureInfo.InvariantCulture) & "）", processRows = 10)
        End Sub

        '==================================================================
        ' 场景2：故障跨班（15:50~16:30），班日志按重叠裁切，故障表存真实起止
        '==================================================================
        Private Sub RunScenarioCrossShiftFault(runner As TestRunner)
            Dim f As New Fixture(BaseDir, "s2_fault")
            Dim svc = f.Service
            Dim plc = f.Plc

            svc.OnPowerOn(New Date(2026, 11, 20, 8, 0, 0))
            svc.UpdateProcessInfo(New Date(2026, 11, 20, 8, 5, 0), 1, 0)
            svc.CheckFaultStatus(New Date(2026, 11, 20, 15, 50, 0), 1, True)   '急停异常
            svc.Tick(New Date(2026, 11, 20, 16, 0, 1))                         '早班收尾（故障仍在）
            svc.UpdateProcessInfo(New Date(2026, 11, 20, 16, 0, 2), 1, 0)      '中班第一工序
            svc.CheckFaultStatus(New Date(2026, 11, 20, 16, 30, 0), 1, False)  '故障恢复

            Dim morningText = f.ReadLog("班施工日志-261120-早班.txt")
            runner.CheckContains("早班日志含故障描述", morningText, "急停异常")
            runner.CheckContains("早班日志故障裁切到16:00", morningText, "2026-11-20 16:00:00")
            runner.CheckContains("早班日志标注故障延续", morningText, "延续至下班")
            runner.CheckNotContains("早班日志故障不再显示未恢复", morningText, "未恢复")

            Dim noonText = f.ReadLog("班施工日志-261120-中班.txt")
            runner.CheckContains("中班日志含跨班故障裁切", noonText, "2026-11-20 16:30:00")

            '故障单独建表：真实起止 15:50~16:30，共 40 分钟，只落一条
            Dim faultText = f.ReadData("fault_records.tsv")
            Dim faultRows = CountRows(faultText, "20261120")
            runner.Check("故障表仅一条记录（实际 " & faultRows.ToString(CultureInfo.InvariantCulture) & "）", faultRows = 1)
            runner.CheckContains("故障表记录真实时长40分钟", faultText, "40.0000")

            '次日生成日日志：故障耗时按当日裁切累计 40 分钟
            plc.DailyAdvanceM = 6.0
            plc.SetCut(WorkShift.Morning, 1)
            svc.CheckOilMtrStatus(New Date(2026, 11, 20, 21, 0, 0), True, False)
            svc.CheckOilMtrStatus(New Date(2026, 11, 20, 22, 0, 0), False, False)
            svc.OnPowerOn(New Date(2026, 11, 21, 2, 0, 0))
            Dim dailyText = f.ReadLog("日施工日志-261120.txt")
            runner.CheckContains("日日志展示故障", dailyText, "急停异常")
            runner.CheckContains("日日志故障耗时40分钟", dailyText, "40.00")
        End Sub

        '==================================================================
        ' 场景3：断电重启后状态恢复（未结束工序/送电时间/最后工序码）
        '==================================================================
        Private Sub RunScenarioRestart(runner As TestRunner)
            Dim f As New Fixture(BaseDir, "s3_restart")

            f.Service.OnPowerOn(New Date(2026, 11, 20, 8, 0, 0))
            f.Service.UpdateProcessInfo(New Date(2026, 11, 20, 8, 5, 0), -1, 0)
            f.Service.UpdateProcessInfo(New Date(2026, 11, 20, 8, 45, 0), 1, 1.0)

            '模拟断电重启：同一日志目录重新构造服务
            Dim svc2 As New ConstructionLogService(f.Config, f.Plc)
            svc2.OnProgramStart()
            svc2.OnPowerOn(New Date(2026, 11, 20, 9, 0, 0))                 '恢复送电（不覆盖首次送电时间）
            svc2.UpdateProcessInfo(New Date(2026, 11, 20, 9, 30, 0), 10, 2.0) '关闭上部左侧，开锚护
            svc2.UpdateProcessInfo(New Date(2026, 11, 20, 10, 0, 0), 0, 2.2)
            svc2.Tick(New Date(2026, 11, 20, 16, 0, 1))

            Dim text = f.ReadLog("班施工日志-261120-早班.txt")
            runner.CheckContains("重启后恢复当班进尺", text, "当班进尺：2.20 m")
            runner.CheckContains("重启后保留第一次送电时间", text, "2026-11-20 08:00:00")
            runner.CheckContains("重启后恢复早班工序", text, "设备检修")
            runner.CheckContains("重启后继续记录新工序", text, "锚护")
            runner.CheckContains("重启后班次正常收尾", text, "班次结束时间：2026-11-20 16:00:00")
            Dim rows = CountRows(f.ReadData("process_records.tsv"), "20261120")
            runner.Check("重启后工序明细不重复（3 条，实际 " & rows.ToString(CultureInfo.InvariantCulture) & "）", rows = 3)
        End Sub

        '==================================================================
        ' 场景4：跨月（11/30 与 12/1 分别落月）
        '==================================================================
        Private Sub RunScenarioCrossMonth(runner As TestRunner)
            Dim f As New Fixture(BaseDir, "s4_cross_month")
            Dim svc = f.Service
            Dim plc = f.Plc

            '----- 11月30日 -----
            svc.OnPowerOn(New Date(2026, 11, 30, 8, 0, 0))
            svc.UpdateProcessInfo(New Date(2026, 11, 30, 8, 10, 0), 1, 5.5)
            svc.Tick(New Date(2026, 11, 30, 16, 0, 1))
            svc.UpdateProcessInfo(New Date(2026, 11, 30, 16, 0, 5), 1, 0)
            svc.UpdateProcessInfo(New Date(2026, 11, 30, 17, 0, 0), 0, 5.5)
            plc.SetCut(WorkShift.Morning, 1)
            plc.SetCut(WorkShift.Noon, 1)
            plc.DailyAdvanceM = 9.5
            svc.Tick(New Date(2026, 12, 1, 0, 0, 1))   '跨日 00:00 → 中班按 24:00 收尾 + 生成日/月日志

            runner.Check("11月日日志已生成", f.Exists("日施工日志-261130.txt"))
            Dim m11 = f.ReadLog("月施工日志-2611.txt")
            runner.CheckContains("11月日志含30日", m11, "30日")
            runner.CheckContains("11月日志含9.50", m11, "9.50")

            '----- 12月1日 -----
            svc.OnPowerOn(New Date(2026, 12, 1, 8, 0, 0))
            svc.UpdateProcessInfo(New Date(2026, 12, 1, 8, 10, 0), 1, 3.0)
            svc.Tick(New Date(2026, 12, 1, 16, 0, 1))
            plc.SetCut(WorkShift.Morning, 1)
            plc.SetCut(WorkShift.Noon, 0)
            plc.DailyAdvanceM = 3.0
            svc.OnPowerOn(New Date(2026, 12, 2, 2, 0, 0))  '跨日第一次送电 → 生成 12/1 日日志

            runner.Check("12月日日志已生成", f.Exists("日施工日志-261201.txt"))
            Dim m12 = f.ReadLog("月施工日志-2612.txt")
            runner.CheckContains("12月日志含1日", m12, "1日")
            runner.CheckContains("12月日志含3.00", m12, "3.00")
            runner.CheckNotContains("11月日志不应被12月数据覆盖", m11, "12-01")
        End Sub

        '==================================================================
        ' 场景5：待开班时段（0~8点且前日中班已收尾）不生成非法"待开班"日志
        '==================================================================
        Private Sub RunScenarioWaitShift(runner As TestRunner)
            Dim f As New Fixture(BaseDir, "s5_wait_shift")
            Dim svc = f.Service

            svc.Tick(New Date(2026, 11, 25, 3, 0, 0))
            svc.UpdateProcessInfo(New Date(2026, 11, 25, 3, 5, 0), 1, 0)       '待开班工序事件应被丢弃
            svc.CheckFaultStatus(New Date(2026, 11, 25, 3, 10, 0), 2, True)   '故障记录到待开班快照（不生成班日志）
            svc.CheckFaultStatus(New Date(2026, 11, 25, 3, 20, 0), 2, False)

            Dim hasWaitShiftFile As Boolean = False
            For Each file In f.LogFileNames()
                If Path.GetFileName(file).Contains("待开班") Then hasWaitShiftFile = True
            Next
            runner.Check("待开班时段不生成班日志文件", Not hasWaitShiftFile)
            runner.Check("待开班工序事件不产生日志", f.LogFileNames().Length = 0)
            runner.CheckContains("待开班故障仍进故障表", f.ReadData("fault_records.tsv"), "20261125")

            '次日送电生成日日志（含待开班故障 10 分钟）
            f.Service.OnPowerOn(New Date(2026, 11, 26, 2, 0, 0))
            Dim dailyText = f.ReadLog("日施工日志-261125.txt")
            runner.CheckContains("日日志含待开班故障", dailyText, "相序异常")
            runner.CheckContains("日日志故障耗时10分钟", dailyText, "10.00")
        End Sub

        '==================================================================
        ' 场景6：中班跨日（泵一直运行到次日 9:00 才停）→ 中班结束时间取泵停时间
        '==================================================================
        Private Sub RunScenarioNoonCrossDay(runner As TestRunner)
            Dim f As New Fixture(BaseDir, "s6_noon_cross_day")
            '中班跨日延续上限放宽到 12 小时，验证"泵停"优先于固定上限
            f.Config.Options.NoonMaxCarryOverHours = 12
            Dim svc = f.Service
            Dim plc = f.Plc

            '----- 12/5 早班 -----
            svc.OnPowerOn(New Date(2026, 12, 5, 8, 0, 0))
            svc.UpdateProcessInfo(New Date(2026, 12, 5, 8, 5, 0), 1, 1.0)
            svc.Tick(New Date(2026, 12, 5, 16, 0, 1))

            '----- 12/5 中班：泵启，跨日后仍运行 -----
            svc.UpdateProcessInfo(New Date(2026, 12, 5, 16, 0, 5), 1, 0)
            svc.CheckOilMtrStatus(New Date(2026, 12, 5, 22, 0, 0), True, False)
            svc.UpdateProcessInfo(New Date(2026, 12, 5, 23, 0, 0), 10, 2.0)
            svc.Tick(New Date(2026, 12, 6, 0, 0, 30))
            runner.Check("跨日泵未停时中班暂不收尾", Not f.Service.IsShiftClosed(New Date(2026, 12, 5), WorkShift.Noon))

            '----- 12/6 早班已开工，9:00 泵停 → 12/5 中班按 9:00 收尾 -----
            svc.OnPowerOn(New Date(2026, 12, 6, 8, 0, 0))
            svc.UpdateProcessInfo(New Date(2026, 12, 6, 8, 0, 5), -1, 0)
            svc.CheckOilMtrStatus(New Date(2026, 12, 6, 9, 0, 0), False, False)
            svc.Tick(New Date(2026, 12, 6, 9, 2, 1))   '默认去抖120s后确认泵停收尾

            runner.Check("跨日泵停后中班收尾", f.Service.IsShiftClosed(New Date(2026, 12, 5), WorkShift.Noon))
            Dim noonText = f.ReadLog("班施工日志-261205-中班.txt")
            runner.CheckContains("跨日中班结束时间取泵停时间", noonText, "班次结束时间：2026-12-06 09:00:00")
            runner.CheckContains("跨日中班末工序结束于泵停时间", noonText, "2026-12-06 09:00:00")
            runner.Check("泵停后补生成 12/5 日日志", f.Exists("日施工日志-261205.txt"))

            '----- 12/6 早班收尾，次日生成 12/6 日日志 -----
            plc.DailyAdvanceM = 5.0
            svc.Tick(New Date(2026, 12, 6, 16, 0, 1))
            svc.OnPowerOn(New Date(2026, 12, 7, 2, 0, 0))
            runner.Check("12/6 日日志已生成", f.Exists("日施工日志-261206.txt"))
            runner.CheckContains("12/6 早班日志已生成", f.ReadLog("班施工日志-261206-早班.txt"), "设备检修")
        End Sub

        '==================================================================
        ' 场景7：配置文件驱动现场参数（班次时间、锚护系数、故障过滤、工序改名）
        '==================================================================
        Private Sub RunScenarioConfigFile(runner As TestRunner)
            Dim root = Path.Combine(BaseDir, "s7_config")
            If Directory.Exists(root) Then Directory.Delete(root, True)
            Dim cfg As New LogConfig()
            cfg.Options.LogRootPath = Path.Combine(root, "logs")

            Dim iniPath = Path.Combine(root, "log_config.ini")
            Directory.CreateDirectory(root)
            Dim iniText = String.Join(Environment.NewLine, New String() {
                "# 现场参数（UTF-8 保存）",
                "LogRootPath=" & cfg.Options.LogRootPath,
                "MorningStartHour=7",
                "MorningEndHour=15",
                "NoonStartHour=16",
                "SupportCables=3",
                "OnlyCountProductionFaults=true",
                "fault.counted.2=false",
                "process.10=锚护作业"
            })
            File.WriteAllText(iniPath, iniText, New UTF8Encoding(False))
            LogConfigFile.Apply(iniPath, cfg)

            runner.Check("配置文件读取早班开始小时", cfg.Options.MorningStartHour = 7)
            runner.Check("配置文件读取早班结束小时", cfg.Options.MorningEndHour = 15)
            runner.Check("配置文件读取锚索折算系数", cfg.Options.SupportCables = 3)
            runner.Check("配置文件启用生产故障过滤", cfg.Options.OnlyCountProductionFaults)
            runner.Check("配置文件屏蔽故障2", Not cfg.ShouldRecordFault(2))
            runner.Check("配置文件覆盖工序名称", cfg.GetProcess(10).Name = "锚护作业")

            Dim plc As New SimulatedPlc()
            Dim svc As New ConstructionLogService(cfg, plc)
            svc.OnPowerOn(New Date(2026, 12, 10, 7, 0, 0))
            svc.UpdateProcessInfo(New Date(2026, 12, 10, 7, 10, 0), 1, 1.0)
            svc.UpdateProcessInfo(New Date(2026, 12, 10, 8, 0, 0), 10, 2.0)
            svc.CheckFaultStatus(New Date(2026, 12, 10, 9, 0, 0), 2, True)   '被过滤，不应记录
            svc.Tick(New Date(2026, 12, 10, 15, 0, 1))                       '早班按配置 15:00 收尾
            '配置 7:00-15:00 早班、15:00 中班；若现场配置成不连续班次，空档期报文应被忽略
            svc.UpdateProcessInfo(New Date(2026, 12, 10, 15, 30, 0), 1, 9.9)
            runner.Check("空档期报文不误建中班日志", Not File.Exists(Path.Combine(cfg.Options.LogRootPath, "Logs", "班施工日志-261210-中班.txt")))

            Dim textPath = Path.Combine(cfg.Options.LogRootPath, "Logs", "班施工日志-261210-早班.txt")
            runner.Check("配置的15:00早班收尾生效", File.Exists(textPath))
            If File.Exists(textPath) Then
                Dim text = File.ReadAllText(textPath, Encoding.GetEncoding("GB18030"))
                runner.CheckContains("配置班次边界写入结束时间", text, "班次结束时间：2026-12-10 15:00:00")
                runner.CheckContains("配置的工序名称生效", text, "锚护作业")
                runner.CheckContains("配置的锚索系数生效", text, "锚索：3 根（3 根/次）")
            End If
        End Sub

        '==================================================================
        ' 场景8：油泵抖动去抖——泵停后在去抖时长内重启，不应结束中班；
        '        确认停泵后以"泵停时刻"作为中班结束时间
        '==================================================================
        Private Sub RunScenarioPumpDebounce(runner As TestRunner)
            Dim f As New Fixture(BaseDir, "s8_pump_debounce")
            f.Config.Options.NoonPumpStopDebounceSeconds = 60
            Dim svc = f.Service

            svc.OnPowerOn(New Date(2026, 12, 15, 8, 0, 0))
            svc.UpdateProcessInfo(New Date(2026, 12, 15, 8, 5, 0), 1, 1.0)
            svc.Tick(New Date(2026, 12, 15, 16, 0, 1))
            svc.UpdateProcessInfo(New Date(2026, 12, 15, 16, 0, 5), 1, 0)

            '泵启 → 19:00 泵停（抖动）→ 19:00:40 重启
            svc.CheckOilMtrStatus(New Date(2026, 12, 15, 17, 0, 0), True, False)
            svc.CheckOilMtrStatus(New Date(2026, 12, 15, 19, 0, 0), False, False)
            runner.Check("泵停去抖期内不收尾", Not svc.IsShiftClosed(New Date(2026, 12, 15), WorkShift.Noon))
            svc.Tick(New Date(2026, 12, 15, 19, 0, 30))
            runner.Check("去抖时长未满不收尾", Not svc.IsShiftClosed(New Date(2026, 12, 15), WorkShift.Noon))
            svc.CheckOilMtrStatus(New Date(2026, 12, 15, 19, 0, 40), True, False)
            svc.Tick(New Date(2026, 12, 15, 19, 2, 0))
            runner.Check("泵重启后取消收尾", Not svc.IsShiftClosed(New Date(2026, 12, 15), WorkShift.Noon))

            '22:00 再次泵停，22:01:01 确认 → 按 22:00 收尾
            svc.CheckOilMtrStatus(New Date(2026, 12, 15, 22, 0, 0), False, False)
            svc.Tick(New Date(2026, 12, 15, 22, 1, 1))
            runner.Check("去抖期满后中班收尾", svc.IsShiftClosed(New Date(2026, 12, 15), WorkShift.Noon))
            Dim text = f.ReadLog("班施工日志-261215-中班.txt")
            runner.CheckContains("中班结束时间取泵停时刻", text, "班次结束时间：2026-12-15 22:00:00")
        End Sub

        '==================================================================
        ' 场景9：独立评审探针问题的回归验证
        '==================================================================
        Private Sub RunScenarioRegression(runner As TestRunner)
            '--- 9a：NoonEndByPumpStop=False 时中班仍应按 24:00 固定收尾 ---
            Dim f1 As New Fixture(BaseDir, "s9a_no_pumpstop")
            f1.Config.Options.NoonEndByPumpStop = False
            f1.Service.OnPowerOn(New Date(2026, 11, 20, 8, 0, 0))
            f1.Service.UpdateProcessInfo(New Date(2026, 11, 20, 8, 5, 0), 1, 1.0)
            f1.Service.Tick(New Date(2026, 11, 20, 16, 0, 1))
            f1.Service.UpdateProcessInfo(New Date(2026, 11, 20, 16, 0, 5), 1, 1.0)
            f1.Service.CheckOilMtrStatus(New Date(2026, 11, 20, 17, 0, 0), True, False)
            f1.Service.CheckOilMtrStatus(New Date(2026, 11, 20, 18, 0, 0), False, False)
            f1.Service.Tick(New Date(2026, 11, 21, 0, 0, 30))
            runner.Check("关闭泵停收尾时中班仍收尾", f1.Service.IsShiftClosed(New Date(2026, 11, 20), WorkShift.Noon))
            runner.Check("关闭泵停收尾时生成日日志", f1.Exists("日施工日志-261120.txt"))
            runner.CheckContains("关闭泵停收尾时结束时间为24:00", f1.ReadLog("班施工日志-261120-中班.txt"), "班次结束时间：2026-11-21 00:00:00")

            '--- 9b：当日未收尾时手工生成日日志应被拒绝 ---
            Dim f2 As New Fixture(BaseDir, "s9b_early_daily")
            f2.Service.OnPowerOn(New Date(2026, 11, 20, 8, 0, 0))
            f2.Service.UpdateProcessInfo(New Date(2026, 11, 20, 8, 5, 0), 1, 1.0)
            f2.Service.Tick(New Date(2026, 11, 20, 16, 0, 1))
            f2.Service.UpdateProcessInfo(New Date(2026, 11, 20, 16, 0, 5), 1, 0)   '中班已开工、未收尾
            Dim early = f2.Service.ForceGenerateDailyLog(New Date(2026, 11, 20), New Date(2026, 11, 20, 16, 5, 0))
            runner.Check("当日未收尾时拒绝手工生成日日志", early Is Nothing)
            runner.Check("拒绝后不生成日日志文件", Not f2.Exists("日施工日志-261120.txt"))
            runner.CheckContains("拒绝原因写入 LastError", If(f2.Service.LastError, ""), "拒绝")

            '--- 9c：时钟前跳后回拨，日日志不能永久停摆 ---
            Dim f3 As New Fixture(BaseDir, "s9c_clock_rollback")
            f3.Service.OnPowerOn(New Date(2026, 11, 20, 8, 0, 0))
            f3.Service.UpdateProcessInfo(New Date(2026, 11, 20, 8, 5, 0), 1, 3.0)
            f3.Service.Tick(New Date(2026, 11, 20, 16, 0, 1))
            f3.Reopen()
            f3.Service.OnProgramStart()
            f3.Service.OnPowerOn(New Date(2026, 11, 23, 8, 0, 0))   '时钟前跳到 11/23
            runner.Check("时钟前跳时补生成 11/20 日日志", f3.Exists("日施工日志-261120.txt"))
            f3.Service.OnPowerOn(New Date(2026, 11, 21, 8, 0, 0))   'NTP 回拨到 11/21
            f3.Service.UpdateProcessInfo(New Date(2026, 11, 21, 8, 5, 0), 1, 2.0)
            f3.Service.Tick(New Date(2026, 11, 21, 16, 0, 1))
            f3.Service.Tick(New Date(2026, 11, 22, 0, 0, 30))
            runner.Check("时钟回拨后 11/21 日日志仍生成", f3.Exists("日施工日志-261121.txt"))

            '--- 9d：跨日重启（中班泵运行未停 + 次日已建早班状态）后补生成昨日日日志 ---
            Dim f4 As New Fixture(BaseDir, "s9d_restart_pending_noon")
            f4.Config.Options.NoonMaxCarryOverHours = 12
            f4.Service.OnPowerOn(New Date(2026, 11, 20, 8, 0, 0))
            f4.Service.UpdateProcessInfo(New Date(2026, 11, 20, 8, 5, 0), 1, 5.5)
            f4.Service.Tick(New Date(2026, 11, 20, 16, 0, 1))
            f4.Service.UpdateProcessInfo(New Date(2026, 11, 20, 16, 0, 5), 1, 5.5)
            f4.Service.CheckOilMtrStatus(New Date(2026, 11, 20, 22, 0, 0), True, False)
            f4.Service.Tick(New Date(2026, 11, 21, 0, 0, 30))      '泵未停，日日志等待
            f4.Service.OnPowerOn(New Date(2026, 11, 21, 8, 0, 0))  '次日早班已建状态文件
            f4.Reopen()                                             '白天重启上位机
            f4.Service.OnProgramStart()
            f4.Service.CheckOilMtrStatus(New Date(2026, 11, 21, 9, 0, 0), False, False)
            f4.Service.Tick(New Date(2026, 11, 21, 9, 2, 1))
            runner.Check("跨日重启后补生成 11/20 日日志", f4.Exists("日施工日志-261120.txt"))
            runner.CheckContains("跨日重启后日汇总表含 11/20", f4.ReadData("daily_summary.tsv"), "20261120|")

            '--- 9e：待开班送电时刻持久化，重启后首个工序仍从班次开始时刻起算 ---
            Dim simDay = Date.Now.Date.AddDays(1)
            Dim f5 As New Fixture(BaseDir, "s9e_pending_persist")
            f5.Service.OnPowerOn(simDay.AddHours(7))          '早班前送电 → 暂存并落盘
            f5.Reopen()                                        '重启上位机
            f5.Service.OnProgramStart()
            f5.Service.UpdateProcessInfo(simDay.AddHours(8).AddMinutes(10), 1, 1.0)
            f5.Service.Tick(simDay.AddHours(16).AddMinutes(1))
            Dim rows5 = f5.ReadData("process_records.tsv")
            runner.CheckContains("重启后送电时刻未丢失（首个工序从08:00起算）", rows5, "2026-")
            runner.Check("重启后首个工序开始=班次开始", rows5.Contains(simDay.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) & " 08:00:00"))

            '--- 9f：正常停机时，中班结束时间取泵停时刻（不受去抖等待影响） ---
            Dim f6 As New Fixture(BaseDir, "s9f_poweroff")
            f6.Service.OnPowerOn(New Date(2026, 11, 20, 8, 0, 0))
            f6.Service.UpdateProcessInfo(New Date(2026, 11, 20, 8, 5, 0), 1, 1.0)
            f6.Service.Tick(New Date(2026, 11, 20, 16, 0, 1))
            f6.Service.UpdateProcessInfo(New Date(2026, 11, 20, 16, 0, 5), 1, 1.0)
            f6.Service.CheckOilMtrStatus(New Date(2026, 11, 20, 17, 0, 0), True, False)
            f6.Service.CheckOilMtrStatus(New Date(2026, 11, 20, 23, 10, 0), False, False)   '泵停
            f6.Service.OnPowerOff(New Date(2026, 11, 20, 23, 10, 30))                        '30 秒后正常停机
            runner.Check("停机后中班已收尾", f6.Service.IsShiftClosed(New Date(2026, 11, 20), WorkShift.Noon))
            runner.CheckContains("停机收尾时间取泵停时刻", f6.ReadLog("班施工日志-261120-中班.txt"), "班次结束时间：2026-11-20 23:10:00")

            '--- 9g：当日（中班尚未开始）禁止手工提前生成日日志 ---
            Dim f7 As New Fixture(BaseDir, "s9g_same_day_daily")
            f7.Service.OnPowerOn(New Date(2026, 11, 20, 8, 0, 0))
            f7.Service.UpdateProcessInfo(New Date(2026, 11, 20, 8, 5, 0), 1, 1.0)
            f7.Service.Tick(New Date(2026, 11, 20, 16, 0, 1))
            Dim sameDay = f7.Service.ForceGenerateDailyLog(New Date(2026, 11, 20), New Date(2026, 11, 20, 16, 5, 0))
            runner.Check("当日禁止手工提前生成日日志", sameDay Is Nothing)
            runner.Check("当日提前生成不落盘", Not f7.Exists("日施工日志-261120.txt"))
            runner.Check("当日提前生成不落日汇总表", Not f7.ReadData("daily_summary.tsv").Contains("20261120|"))

            '--- 9h：日汇总已存在但日日志文本丢失时，用汇总自愈重渲染 ---
            Dim f8 As New Fixture(BaseDir, "s9h_daily_self_heal")
            f8.Service.OnPowerOn(New Date(2026, 11, 20, 8, 0, 0))
            f8.Service.UpdateProcessInfo(New Date(2026, 11, 20, 8, 5, 0), 1, 2.5)
            f8.Service.Tick(New Date(2026, 11, 20, 16, 0, 1))
            f8.Service.UpdateProcessInfo(New Date(2026, 11, 20, 16, 0, 5), 10, 2.5)
            f8.Service.Tick(New Date(2026, 11, 21, 2, 0, 0))     '跨日生成 11/20 日日志
            runner.Check("自愈前日日志已生成", f8.Exists("日施工日志-261120.txt"))
            File.Delete(f8.LogPath("日施工日志-261120.txt"))       '模拟文本误删/损坏
            Dim healed = f8.Service.ForceGenerateDailyLog(New Date(2026, 11, 20), New Date(2026, 11, 21, 3, 0, 0))
            runner.Check("用日汇总自愈重渲染日日志", healed IsNot Nothing)
            runner.Check("自愈后日日志文件恢复", f8.Exists("日施工日志-261120.txt"))
            runner.CheckContains("自愈后日日志含汇总数据", f8.ReadLog("日施工日志-261120.txt"), "合计：进刀 1 次；锚护 1 次")
        End Sub

        '==================================================================
        ' 辅助方法
        '==================================================================
        Private Function CanOpenExclusive(path As String) As Boolean
            Try
                Using fs As New FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)
                    Return True
                End Using
            Catch ex As Exception
                Return False
            End Try
        End Function

        Private Function FindRow(text As String, prefix As String) As String
            If String.IsNullOrEmpty(text) Then Return Nothing
            For Each line In text.Split(New String() {Environment.NewLine}, StringSplitOptions.RemoveEmptyEntries)
                If line.StartsWith(prefix & "|", StringComparison.Ordinal) Then Return line
            Next
            Return Nothing
        End Function

        Private Function CountRows(text As String, prefix As String) As Integer
            If String.IsNullOrEmpty(text) Then Return 0
            Dim count As Integer = 0
            For Each line In text.Split(New String() {Environment.NewLine}, StringSplitOptions.RemoveEmptyEntries)
                If line.StartsWith(prefix & "|", StringComparison.Ordinal) Then count += 1
            Next
            Return count
        End Function

    End Module

End Namespace
