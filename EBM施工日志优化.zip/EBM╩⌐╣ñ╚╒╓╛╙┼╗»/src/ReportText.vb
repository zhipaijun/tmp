﻿'==============================================================================
' 文件：ReportText.vb
' 作用：文本报表按"显示宽度"对齐（中文全角占 2 格），保证记事本/Excel 中列对齐
'       .NET 的 String.PadRight 按字符数补齐，中文列会错位，这里按 GB18030 字节宽度计算。
'==============================================================================

Imports System
Imports System.Text

Namespace Ebm.ConstructionLog

    ''' <summary>文本报表排版工具</summary>
    Friend NotInheritable Class ReportText
        Private Shared ReadOnly _widthEncoding As Encoding = GetWidthEncoding()

        Private Sub New()
        End Sub

        Private Shared Function GetWidthEncoding() As Encoding
            Try
                Return Encoding.GetEncoding("GB18030")
            Catch ex As Exception
                Return Encoding.Default
            End Try
        End Function

        ''' <summary>显示宽度：ASCII=1，中文/全角=2</summary>
        Public Shared Function Width(text As String) As Integer
            If String.IsNullOrEmpty(text) Then Return 0
            Return _widthEncoding.GetByteCount(text)
        End Function

        Public Shared Function PadRightDisplay(text As String, displayWidth As Integer) As String
            Dim t = If(text, "")
            Dim w = Width(t)
            If w >= displayWidth Then Return t
            Return t & New String(" "c, displayWidth - w)
        End Function

        Public Shared Function PadLeftDisplay(text As String, displayWidth As Integer) As String
            Dim t = If(text, "")
            Dim w = Width(t)
            If w >= displayWidth Then Return t
            Return New String(" "c, displayWidth - w) & t
        End Function

        ''' <summary>输出一行；widths 为各列显示宽度，最后一列可左对齐或右对齐</summary>
        Public Shared Function Row(widths As Integer(), cells As String(), rightAlignLast As Boolean) As String
            Dim sb As New StringBuilder
            For i As Integer = 0 To cells.Length - 1
                Dim cell = If(cells(i), "")
                Dim w = If(i < widths.Length, widths(i), 0)
                If i = cells.Length - 1 Then
                    If rightAlignLast Then
                        sb.Append(PadLeftDisplay(cell, w))
                    Else
                        sb.Append(cell)
                    End If
                Else
                    sb.Append(PadRightDisplay(cell, w))
                End If
            Next
            Return sb.ToString()
        End Function

        Public Shared Function Row(widths As Integer(), cells As String()) As String
            Return Row(widths, cells, False)
        End Function
    End Class

End Namespace
