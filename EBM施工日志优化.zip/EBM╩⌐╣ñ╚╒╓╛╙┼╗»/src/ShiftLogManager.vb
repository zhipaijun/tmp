﻿Option Explicit On
Option Strict Off
Option Infer On
'==============================================================================
' 文件：ShiftLogManager.vb
' 作用：班施工日志核心管理器（工序切换、故障起止、进尺、油泵收尾、掉电恢复、日志实时刷新）
'
' 与原代码相比修复/增强：
'   1) 修复原代码无法编译的问题（Private 顶层类、ReadOnly 自动属性、字符串插值）；
'   2) 班次解析支持跨日：0:00~8:00 归前一日中班，中班以泵停为结束（可配置）；
'   3) 工序编码 0（无/停机）不再生成"无"工序行，只关闭上一条工序；
'   4) 第一次写入时间取设备第一次送电时间；
'   5) 早班 16:00 固定收尾，收尾时间按班次边界裁切，不会因为调用时刻跨班而收错班；
'   6) 故障跨班/跨日可正确定位与关闭，班日志按时间窗裁切展示，不篡改真实起止；
'   7) 日志"整文件原子写 + 不占用句柄"，任意时刻可拷贝；刷新有节流；
'   8) 班次状态快照落盘，重启后恢复，避免丢当班记录；
'   9) 工序/故障明细落表，供日/月日志累计统计。
'==============================================================================

Imports System
Imports System.Collections.Generic
Imports System.Globalization
Imports System.Text

Namespace Ebm.ConstructionLog

    ''' <summary>班施工日志管理器（线程安全；不持有文件句柄）</summary>
    Public Class ShiftLogManager
        Private ReadOnly _config As LogConfig
        Private ReadOnly _options As LogOptions
        Private ReadOnly _fs As LogFileSystem
        Private ReadOnly _paths As LogPaths
        Private ReadOnly _stateStore As ShiftStateStore
        Private ReadOnly _tables As RecordTables
        Private ReadOnly _snapshots As New Dictionary(Of String, ShiftSnapshot)
        Private ReadOnly _gate As New Object()
        ''' <summary>待开班时段收到的送电时刻，用于该班次第一个工序从送电时刻起算</summary>
        Private _pendingPowerOn As Date?

        Public Sub New(config As LogConfig, fs As LogFileSystem, paths As LogPaths, stateStore As ShiftStateStore, tables As RecordTables)
            _config = config
            _options = config.Options
            _fs = fs
            _paths = paths
            _stateStore = stateStore
            _tables = tables
            LoadPendingPowerOn()
        End Sub

        '==================================================================
        ' 对外查询
        '==================================================================
        ''' <summary>获取班次快照（不存在返回 Nothing；会尝试从状态文件恢复）</summary>
        Public Function GetSnapshot(key As ShiftKey) As ShiftSnapshot
            SyncLock _gate
                Return GetSnapshotCore(key)
            End SyncLock
        End Function

        ''' <summary>班次是否已收尾</summary>
        Public Function IsShiftClosed(key As ShiftKey) As Boolean
            Dim snap = GetSnapshot(key)
            Return snap IsNot Nothing AndAlso snap.IsClosed
        End Function

        ''' <summary>读取某班次当前（或收尾时）进尺（米）</summary>
        Public Function GetShiftAdvanceM(key As ShiftKey) As Double
            Dim snap = GetSnapshot(key)
            If snap Is Nothing Then Return 0
            Return snap.AdvanceM
        End Function

        ''' <summary>中班两台油泵是否都已停止（中班收尾判断，保留原 API）</summary>
        Public Function IsAllOilMtrStop(day As Date) As Boolean
            Dim snap = GetSnapshot(New ShiftKey(day, WorkShift.Noon))
            If snap Is Nothing Then Return True
            Return (Not snap.OilPump1Run) AndAlso (Not snap.OilPump2Run)
        End Function

        '==================================================================
        ' 采集入口
        '==================================================================
        ''' <summary>
        ''' 设备第一次送电（或每次上电）时调用。
        ''' 需求：第一次写入时间为设备第一次送电时间——记录 PowerOnTime，后续第一个工序从该时刻起算。
        ''' </summary>
        Public Sub OnPowerOn(nowTime As Date)
            SyncLock _gate
                Dim key = ResolveActiveShift(nowTime)
                If key Is Nothing Then
                    '待开班时段送电（如 0~8 点）：暂存时刻并落盘，等该班次第一个事件到达时使用
                    _pendingPowerOn = nowTime
                    SavePendingPowerOn()
                    Return
                End If
                Dim snap = GetOrCreateSnapshot(key)
                If snap.IsClosed Then Return

                If Not snap.PowerOnTime.HasValue Then
                    snap.PowerOnTime = ConsumePendingPowerOn(nowTime)
                End If
                MarkDataStart(snap, nowTime)
                FlushReport(snap, nowTime, True)
                SaveState(snap)
            End SyncLock
        End Sub

        ''' <summary>CAN 报文入口：工序信息 + 当班进尺</summary>
        Public Sub UpdateProcessInfo(nowTime As Date, procCode As Integer, inchageRaw As Double)
            SyncLock _gate
                Dim key = ResolveActiveShift(nowTime)
                If key Is Nothing Then Return
                Dim snap = GetOrCreateSnapshot(key)
                If snap.IsClosed Then Return
                If Not snap.PowerOnTime.HasValue Then snap.PowerOnTime = ConsumePendingPowerOn(nowTime)

                '进尺是下位机掉电保存变量，每次采样都刷新
                If inchageRaw >= 0 Then snap.AdvanceM = inchageRaw

                Dim oldCode = snap.LastProcessCode
                If procCode <> oldCode Then
                    '工序变化：写入上一工序结束时间 + 当前工序开始时间
                    CloseOpenProcess(snap, nowTime)
                    If procCode <> 0 Then
                        Dim startTime As Date
                        If oldCode = 0 AndAlso snap.ProcessList.Count = 0 Then
                            '第一次写入：取设备第一次送电时间（不早于班次固定开始时间，不晚于当前）
                            startTime = GetFirstWriteTime(snap, nowTime)
                        Else
                            startTime = nowTime
                        End If
                        OpenProcess(snap, procCode, startTime)
                    End If
                    snap.LastProcessCode = procCode
                    MarkDataStart(snap, nowTime)
                    FlushReport(snap, nowTime, True)
                    SaveState(snap)
                Else
                    '工序未变：仅进尺变化，按节流刷新日志
                    FlushReport(snap, nowTime, False)
                End If
            End SyncLock
        End Sub

        ''' <summary>
        ''' 油泵状态采集入口。中班油泵启动后再停止 → 中班结束，结束时间取泵停时间。
        ''' 返回值：本次调用导致收尾的班次（无则 Nothing），由上层下发标志位。
        ''' </summary>
        Public Function CheckOilMtrStatus(nowTime As Date, mtr1Run As Boolean, mtr2Run As Boolean) As ShiftKey
            SyncLock _gate
                Dim closedKey As ShiftKey = Nothing

                '1) 跨日的中班：泵停后仍按"泵停时间"收尾（即使已跨入次日早班时段）
                Dim prevNoonKey = New ShiftKey(nowTime.Date.AddDays(-1), WorkShift.Noon)
                Dim prevNoon = GetSnapshotCore(prevNoonKey)
                If prevNoon IsNot Nothing AndAlso Not prevNoon.IsClosed Then
                    Dim prevChanged = UpdatePumpState(prevNoon, nowTime, mtr1Run, mtr2Run)
                    If prevChanged Then
                        MarkDataStart(prevNoon, nowTime)
                        SaveState(prevNoon)
                    End If
                    If TryCloseNoonByPumpStop(prevNoon, nowTime) Then
                        closedKey = prevNoonKey
                    ElseIf prevChanged Then
                        FlushReport(prevNoon, nowTime, True)
                    End If
                End If

                '2) 当前班次油泵状态维护 + 当日中班泵停收尾
                Dim key = ResolveActiveShift(nowTime)
                If key IsNot Nothing Then
                    Dim snap = GetOrCreateSnapshot(key)
                    If Not snap.IsClosed AndAlso (closedKey Is Nothing OrElse Not key.Equals(closedKey)) Then
                        Dim changed = UpdatePumpState(snap, nowTime, mtr1Run, mtr2Run)
                        If changed Then
                            MarkDataStart(snap, nowTime)
                            SaveState(snap)
                        End If
                        If TryCloseNoonByPumpStop(snap, nowTime) Then
                            closedKey = key
                        ElseIf changed Then
                            FlushReport(snap, nowTime, True)
                        End If
                    End If
                End If
                Return closedKey
            End SyncLock
        End Function

        ''' <summary>
        ''' 多路故障状态采集入口（内部查表，不传描述）。
        ''' 故障可能跨班/跨日：本方法通过扫描相邻班次快照定位"仍在运行"的同一故障，避免起止丢失。
        ''' </summary>
        Public Sub CheckFaultStatus(nowTime As Date, faultId As Integer, faultFlag As Boolean)
            SyncLock _gate
                If Not _config.ShouldRecordFault(faultId) Then Return

                Dim runningOwner = FindRunningFaultOwner(faultId, nowTime)
                If faultFlag Then
                    '上升沿：故障开始（若已存在运行中的同一故障则不重复记录）
                    If runningOwner IsNot Nothing Then Return
                    Dim key = ResolveActiveShift(nowTime)
                    If key Is Nothing Then
                        '待开班时段出现的故障：记到当日的"待开班"快照，不进班日志，进日日志故障表
                        key = New ShiftKey(nowTime.Date, WorkShift.None)
                    End If
                    Dim snap = GetOrCreateSnapshot(key)
                    '只有正式班次才消费送电时刻；待开班快照不消费，留给该班次第一个工序
                    If key.Shift <> WorkShift.None AndAlso Not snap.PowerOnTime.HasValue Then
                        snap.PowerOnTime = ConsumePendingPowerOn(nowTime)
                    End If
                    Dim def = _config.GetFault(faultId)
                    snap.FaultList.Add(New FaultRecord With {
                        .FaultId = faultId,
                        .FaultDesc = def.Name,
                        .StartTime = nowTime
                    })
                    MarkDataStart(snap, nowTime)
                    FlushReport(snap, nowTime, True)
                    SaveState(snap)
                Else
                    '下降沿：故障结束（可能是别的班次记录的，需回到所属快照关闭）
                    If runningOwner Is Nothing Then Return
                    Dim rec = runningOwner.FindRunningFault(faultId)
                    If rec Is Nothing Then Return
                    rec.EndTime = If(nowTime < rec.StartTime, rec.StartTime, nowTime)
                    _tables.AppendFault(runningOwner.Key.LogDate, runningOwner.Key.Shift, rec)
                    FlushReport(runningOwner, nowTime, True)
                    SaveState(runningOwner)

                    '当前班次日志也刷新一次（跨班故障按重叠时间裁切展示）
                    Dim activeKey = ResolveActiveShift(nowTime)
                    If activeKey IsNot Nothing Then
                        Dim activeSnap = GetOrCreateSnapshot(activeKey)
                        If activeSnap IsNot runningOwner Then FlushReport(activeSnap, nowTime, True)
                    End If
                End If
            End SyncLock
        End Sub

        ''' <summary>PLC 主循环周期调用（建议 1 秒）：班次固定边界收尾 + 日志节流刷新</summary>
        Public Function Tick(nowTime As Date) As List(Of ShiftKey)
            SyncLock _gate
                Dim closedKeys As New List(Of ShiftKey)

                '1) 早班固定 16:00 收尾（收尾时间用班次边界，保证早/中班分界准确）
                Dim morningKey = New ShiftKey(nowTime.Date, WorkShift.Morning)
                Dim morningEnd = _config.GetShiftFixedEnd(morningKey)
                If nowTime >= morningEnd Then
                    If CloseShiftIfOpen(morningKey, morningEnd, "早班到点收尾") Then closedKeys.Add(morningKey)
                End If

                '2) 中班收尾：泵启过则以泵停为准（已在 CheckOilMtrStatus 处理），否则 24:00 固定收尾；
                '   泵一直不停则最多延续到次日 NoonMaxCarryOverHours 点强制收尾
                Dim noonCandidates As New List(Of ShiftKey)
                noonCandidates.Add(New ShiftKey(nowTime.Date, WorkShift.Noon))
                noonCandidates.Add(New ShiftKey(nowTime.Date.AddDays(-1), WorkShift.Noon))
                For Each nk In noonCandidates
                    Dim snap = GetSnapshotCore(nk)
                    If snap Is Nothing OrElse snap.IsClosed OrElse Not snap.HasData Then Continue For
                    '泵已停且去抖时间已过 → 以泵停时刻收尾（优先级最高）
                    If TryCloseNoonByPumpStop(snap, nowTime) Then
                        closedKeys.Add(nk)
                        Continue For
                    End If
                    '泵停去抖期未满：等待确认，不按固定边界收尾（仅在启用泵停收尾时生效）
                    If _options.NoonEndByPumpStop AndAlso snap.PumpStopCandidate.HasValue AndAlso Not (snap.OilPump1Run OrElse snap.OilPump2Run) Then Continue For
                    Dim fixedEnd = _config.GetShiftFixedEnd(nk)
                    Dim carryLimit = nk.LogDate.AddDays(1).AddHours(_options.NoonMaxCarryOverHours)
                    If _options.NoonEndByPumpStop AndAlso snap.PumpEverStarted AndAlso (snap.OilPump1Run OrElse snap.OilPump2Run) Then
                        If nowTime >= carryLimit Then
                            If CloseShiftIfOpen(nk, carryLimit, "中班跨日超过上限强制收尾") Then closedKeys.Add(nk)
                        End If
                    ElseIf nowTime >= fixedEnd Then
                        If CloseShiftIfOpen(nk, fixedEnd, "中班到点收尾") Then closedKeys.Add(nk)
                    End If
                Next

                '3) 进行中日志按节流刷新（保证现场随时可拷出较新内容）
                For Each snap In New List(Of ShiftSnapshot)(_snapshots.Values)
                    If Not snap.IsClosed AndAlso snap.HasData Then FlushReport(snap, nowTime, False)
                Next
                Return closedKeys
            End SyncLock
        End Function

        ''' <summary>
        ''' 日收尾前置处理：把某日仍未收尾的班次按边界收尾。
        ''' 中班若仍处于"泵在运行且未到延续上限"状态则不收尾，返回 False 表示该日还不能生成日日志。
        ''' </summary>
        Public Function FinalizeDayShifts(day As Date, nowTime As Date) As List(Of ShiftKey)
            SyncLock _gate
                Dim closedKeys As New List(Of ShiftKey)

                Dim morningKey = New ShiftKey(day, WorkShift.Morning)
                Dim morningEnd = _config.GetShiftFixedEnd(morningKey)
                If nowTime >= morningEnd Then
                    If CloseShiftIfOpen(morningKey, morningEnd, "日收尾（早班）") Then closedKeys.Add(morningKey)
                End If

                Dim noonKey = New ShiftKey(day, WorkShift.Noon)
                Dim noonSnap = GetSnapshotCore(noonKey)
                If noonSnap IsNot Nothing AndAlso Not noonSnap.IsClosed AndAlso noonSnap.HasData Then
                    If TryCloseNoonByPumpStop(noonSnap, nowTime) Then
                        closedKeys.Add(noonKey)
                    ElseIf _options.NoonEndByPumpStop AndAlso noonSnap.PumpStopCandidate.HasValue AndAlso Not (noonSnap.OilPump1Run OrElse noonSnap.OilPump2Run) Then
                        '泵停去抖期未满：等待下一次确认，不按固定边界收尾
                    Else
                        Dim fixedEnd = _config.GetShiftFixedEnd(noonKey)
                        Dim carryLimit = day.AddDays(1).AddHours(_options.NoonMaxCarryOverHours)
                        If _options.NoonEndByPumpStop AndAlso noonSnap.PumpEverStarted AndAlso (noonSnap.OilPump1Run OrElse noonSnap.OilPump2Run) Then
                            If nowTime >= carryLimit Then
                                If CloseShiftIfOpen(noonKey, carryLimit, "日收尾（中班跨日超上限）") Then closedKeys.Add(noonKey)
                            End If
                        Else
                            If nowTime >= fixedEnd Then
                                If CloseShiftIfOpen(noonKey, fixedEnd, "日收尾（中班）") Then closedKeys.Add(noonKey)
                            End If
                        End If
                    End If
                End If
                Return closedKeys
            End SyncLock
        End Function

        ''' <summary>某日两个班次是否都已收尾（无数据视为已完成）</summary>
        Public Function IsDayClosed(day As Date) As Boolean
            Dim morning = GetSnapshot(New ShiftKey(day, WorkShift.Morning))
            If morning IsNot Nothing AndAlso Not morning.IsClosed Then Return False
            Dim noon = GetSnapshot(New ShiftKey(day, WorkShift.Noon))
            If noon IsNot Nothing AndAlso Not noon.IsClosed Then Return False
            Return True
        End Function

        ''' <summary>某日是否存在需要写日志的数据</summary>
        Public Function HasDayData(day As Date) As Boolean
            For Each shift In New WorkShift() {WorkShift.Morning, WorkShift.Noon, WorkShift.None}
                Dim snap = GetSnapshot(New ShiftKey(day, shift))
                If snap IsNot Nothing AndAlso snap.HasData Then Return True
            Next
            Return False
        End Function

        ''' <summary>
        ''' 正常停机调用：把当前仍在进行的班次按停机时刻收尾，并关闭运行中的故障。
        ''' （突然断电不在本方法覆盖范围，依赖状态快照与下位机掉电保存变量恢复）
        ''' </summary>
        Public Function OnPowerOff(nowTime As Date) As List(Of ShiftKey)
            SyncLock _gate
                Dim closedKeys As New List(Of ShiftKey)
                Dim candidates As New List(Of ShiftKey)
                candidates.Add(New ShiftKey(nowTime.Date, WorkShift.Morning))
                candidates.Add(New ShiftKey(nowTime.Date, WorkShift.Noon))
                candidates.Add(New ShiftKey(nowTime.Date.AddDays(-1), WorkShift.Noon))
                candidates.Add(New ShiftKey(nowTime.Date, WorkShift.None))

                For Each key In candidates
                    Dim snap = GetSnapshotCore(key)
                    If snap Is Nothing Then Continue For

                    '关闭运行中故障（写入真实结束时间）
                    For Each ft In snap.FaultList
                        If ft.IsRunning AndAlso nowTime >= ft.StartTime Then
                            ft.EndTime = nowTime
                            _tables.AppendFault(snap.Key.LogDate, snap.Key.Shift, ft)
                        End If
                    Next

                    Dim closeEnd = nowTime
                    '停机时若中班泵已停，结束时间取泵停时刻（避免去抖等待导致结束时间晚于泵停）
                    If snap.Key.Shift = WorkShift.Noon AndAlso _options.NoonEndByPumpStop AndAlso snap.PumpStopCandidate.HasValue Then
                        closeEnd = snap.PumpStopCandidate.Value
                    End If
                    If Not snap.IsClosed AndAlso snap.HasData AndAlso _config.IsReportableShift(key) _
                       AndAlso closeEnd >= _config.GetShiftFixedStart(key) Then
                        CloseShiftCore(snap, closeEnd, "正常停机收尾")
                        closedKeys.Add(key)
                    Else
                        FlushReport(snap, nowTime, True)
                        SaveState(snap)
                    End If
                Next
                Return closedKeys
            End SyncLock
        End Function

        '==================================================================
        ' 供日/月日志使用
        '==================================================================
        ''' <summary>收集与某日有交集的运行中故障（含仍在运行、尚未落表的）</summary>
        Public Function GetRunningFaultsForDay(day As Date) As List(Of FaultRecord)
            Dim list As New List(Of FaultRecord)
            Dim dayStart = day.Date
            Dim dayEnd = day.Date.AddDays(1)
            For Each offset In New Integer() {-1, 0, 1}
                For Each shift In New WorkShift() {WorkShift.Morning, WorkShift.Noon, WorkShift.None}
                    Dim snap = GetSnapshot(New ShiftKey(dayStart.AddDays(offset), shift))
                    If snap Is Nothing Then Continue For
                    For Each ft In snap.FaultList
                        If ft.IsRunning AndAlso ft.StartTime < dayEnd Then list.Add(ft)
                    Next
                Next
            Next
            Return list
        End Function

        ''' <summary>
        ''' 清理指定日期之前的内存快照（状态文件保留，需要时自动重新加载），防止长期运行内存膨胀。
        ''' 仅清理已收尾/无数据的快照，跨日未收尾的中班不受影响。
        ''' </summary>
        Public Sub EvictSnapshotsBefore(day As Date)
            SyncLock _gate
                Dim keys As New List(Of String)
                For Each pair In _snapshots
                    Dim snap = pair.Value
                    If snap.Key IsNot Nothing AndAlso snap.Key.LogDate < day.Date Then
                        If snap.IsClosed OrElse Not snap.HasData Then keys.Add(pair.Key)
                    End If
                Next
                For Each k In keys
                    _snapshots.Remove(k)
                Next
            End SyncLock
        End Sub

        ''' <summary>读取班次报本文本（测试/导出用）</summary>
        Public Function BuildShiftReportText(key As ShiftKey) As String
            SyncLock _gate
                If Not _config.IsReportableShift(key) Then Return ""
                Dim snap = GetSnapshotCore(key)
                If snap Is Nothing Then Return ""
                Dim viewTime = If(snap.EndTime.HasValue, snap.EndTime.Value, Date.Now)
                Return BuildShiftReport(snap, viewTime)
            End SyncLock
        End Function

        '==================================================================
        ' 内部：状态获取/持久化
        '==================================================================
        Private Function GetSnapshotCore(key As ShiftKey) As ShiftSnapshot
            Dim snap As ShiftSnapshot = Nothing
            If _snapshots.TryGetValue(key.CacheKey, snap) Then Return snap
            snap = _stateStore.Load(key)
            If snap IsNot Nothing Then
                snap.Key = key
                _snapshots(key.CacheKey) = snap
            End If
            Return snap
        End Function

        Private Function GetOrCreateSnapshot(key As ShiftKey) As ShiftSnapshot
            Dim snap = GetSnapshotCore(key)
            If snap Is Nothing Then
                snap = New ShiftSnapshot With {.Key = key}
                _snapshots(key.CacheKey) = snap
            End If
            Return snap
        End Function

        Private Sub SaveState(snap As ShiftSnapshot)
            _stateStore.Save(snap)
        End Sub

        Private Sub MarkDataStart(snap As ShiftSnapshot, nowTime As Date)
            If Not snap.StartTime.HasValue Then
                Dim fixedStart = _config.GetShiftFixedStart(snap.Key)
                snap.StartTime = If(nowTime < fixedStart, fixedStart, nowTime)
            End If
        End Sub

        ''' <summary>解析当前时间所属班次；待开班/已收尾返回 Nothing</summary>
        Private Function ResolveActiveShift(nowTime As Date) As ShiftKey
            Dim key = _config.ResolveShift(nowTime)
            If key.Shift = WorkShift.None Then Return Nothing
            Dim snap = GetSnapshotCore(key)
            If snap IsNot Nothing AndAlso snap.IsClosed Then Return Nothing
            If nowTime.Hour < _options.MorningStartHour Then
                '0~8 点跨日：只有前一日中班确有数据且未收尾时才继续归属
                If snap Is Nothing OrElse Not snap.HasData Then Return Nothing
            End If
            Return key
        End Function

        ''' <summary>取出并清空暂存的送电时刻；超过 24 小时的旧值视为过期；同时清理落盘文件</summary>
        Private Function ConsumePendingPowerOn(nowTime As Date) As Date
            Dim result = nowTime
            If _pendingPowerOn.HasValue Then
                If (nowTime - _pendingPowerOn.Value).TotalHours <= 24 AndAlso _pendingPowerOn.Value <= nowTime Then
                    result = _pendingPowerOn.Value
                End If
                _pendingPowerOn = Nothing
                SavePendingPowerOn()
            End If
            Return result
        End Function

        ''' <summary>重启后恢复待开班时段暂存的送电时刻（超过 24 小时丢弃）</summary>
        Private Sub LoadPendingPowerOn()
            Try
                Dim text = _fs.ReadAllText(_paths.PendingPowerOnFile)
                If String.IsNullOrEmpty(text) Then Return
                Dim dt As Date
                If Date.TryParseExact(text.Trim(), "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, dt) Then
                    If Math.Abs((Date.Now - dt).TotalHours) <= 24 Then _pendingPowerOn = dt
                End If
            Catch ex As Exception
            End Try
        End Sub

        Private Sub SavePendingPowerOn()
            Try
                If _pendingPowerOn.HasValue Then
                    _fs.WriteAllTextAtomic(_paths.PendingPowerOnFile, _pendingPowerOn.Value.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture))
                ElseIf _fs.FileExists(_paths.PendingPowerOnFile) Then
                    System.IO.File.Delete(_paths.PendingPowerOnFile)
                End If
            Catch ex As Exception
            End Try
        End Sub

        Private Function GetFirstWriteTime(snap As ShiftSnapshot, nowTime As Date) As Date
            Dim fixedStart = _config.GetShiftFixedStart(snap.Key)
            Dim candidate = nowTime
            If snap.PowerOnTime.HasValue Then candidate = snap.PowerOnTime.Value
            If candidate < fixedStart Then candidate = fixedStart
            If candidate > nowTime Then candidate = nowTime
            Return candidate
        End Function

        '==================================================================
        ' 内部：工序
        '==================================================================
        Private Sub OpenProcess(snap As ShiftSnapshot, procCode As Integer, startTime As Date)
            Dim def = _config.GetProcess(procCode)
            snap.ProcessList.Add(New ProcessRecord With {
                .Code = procCode,
                .Name = def.Name,
                .Category = def.Category,
                .StartTime = startTime
            })
        End Sub

        ''' <summary>关闭当前未结束工序，并把工序明细落表</summary>
        Private Sub CloseOpenProcess(snap As ShiftSnapshot, endTime As Date)
            Dim rec = snap.OpenProcess
            If rec Is Nothing Then Return
            Dim endT = endTime
            If endT < rec.StartTime Then endT = rec.StartTime
            rec.EndTime = endT
            _tables.AppendProcess(snap.Key.LogDate, snap.Key.Shift, rec)
        End Sub

        '==================================================================
        ' 内部：故障
        '==================================================================
        ''' <summary>跨班/跨日查找仍在运行的同一故障所属快照</summary>
        Private Function FindRunningFaultOwner(faultId As Integer, nowTime As Date) As ShiftSnapshot
            For offset As Integer = 0 To -3 Step -1
                Dim day = nowTime.Date.AddDays(offset)
                For Each shift In New WorkShift() {WorkShift.Noon, WorkShift.Morning, WorkShift.None}
                    Dim snap = GetSnapshotCore(New ShiftKey(day, shift))
                    If snap Is Nothing Then Continue For
                    If snap.FindRunningFault(faultId) IsNot Nothing Then Return snap
                Next
            Next
            Return Nothing
        End Function

        '==================================================================
        ' 内部：班次收尾 / 报文
        '==================================================================
        ''' <summary>更新油泵状态并维护"泵停候选"（去抖）。返回状态是否变化。</summary>
        Private Function UpdatePumpState(snap As ShiftSnapshot, nowTime As Date, mtr1Run As Boolean, mtr2Run As Boolean) As Boolean
            Dim wasRunning = snap.OilPump1Run OrElse snap.OilPump2Run
            Dim nowRunning = mtr1Run OrElse mtr2Run
            If nowRunning Then snap.PumpEverStarted = True

            Dim changed = (snap.OilPump1Run <> mtr1Run) OrElse (snap.OilPump2Run <> mtr2Run)
            snap.OilPump1Run = mtr1Run
            snap.OilPump2Run = mtr2Run

            If _options.NoonEndByPumpStop Then
                If Not nowRunning AndAlso wasRunning Then
                    '下降沿：记录泵停时刻，作为中班结束时间候选
                    snap.PumpStopCandidate = nowTime
                ElseIf nowRunning AndAlso Not wasRunning Then
                    '泵重启：取消待确认的泵停（抖动保护）
                    snap.PumpStopCandidate = Nothing
                End If
            Else
                '未启用泵停收尾时忽略泵停候选，避免永久阻塞固定边界收尾
                snap.PumpStopCandidate = Nothing
            End If
            Return changed
        End Function

        ''' <summary>
        ''' 中班泵停收尾：泵已停且去抖时间已过 → 以"泵停时刻"作为中班结束时间。
        ''' 泵停后在去抖时长内重启会取消候选，避免油泵抖动误结束中班。
        ''' </summary>
        Private Function TryCloseNoonByPumpStop(snap As ShiftSnapshot, nowTime As Date) As Boolean
            If snap Is Nothing OrElse snap.IsClosed Then Return False
            If snap.Key.Shift <> WorkShift.Noon OrElse Not _options.NoonEndByPumpStop Then Return False
            If Not snap.PumpStopCandidate.HasValue Then Return False
            If snap.OilPump1Run OrElse snap.OilPump2Run Then Return False
            Dim candidate = snap.PumpStopCandidate.Value
            Dim debounceEnd = candidate.AddSeconds(Math.Max(0, _options.NoonPumpStopDebounceSeconds))
            If nowTime < debounceEnd Then Return False
            CloseShiftCore(snap, candidate, "中班油泵停止")
            Return True
        End Function

        Private Function CloseShiftIfOpen(key As ShiftKey, endTime As Date, reason As String) As Boolean
            Dim snap = GetSnapshotCore(key)
            If snap Is Nothing OrElse snap.IsClosed OrElse Not snap.HasData Then Return False
            CloseShiftCore(snap, endTime, reason)
            Return True
        End Function

        Private Sub CloseShiftCore(snap As ShiftSnapshot, endTime As Date, reason As String)
            If snap.IsClosed Then Return
            Dim fixedStart = _config.GetShiftFixedStart(snap.Key)
            Dim endT = endTime
            If endT < fixedStart Then endT = fixedStart

            '闭合所有未结束工序（正常只有一条；循环保证不遗漏）
            For Each rec In New List(Of ProcessRecord)(snap.ProcessList)
                If rec.IsClosed Then Continue For
                Dim itemEnd = endT
                If itemEnd < rec.StartTime Then itemEnd = rec.StartTime
                rec.EndTime = itemEnd
                _tables.AppendProcess(snap.Key.LogDate, snap.Key.Shift, rec)
            Next

            '故障不在此强制闭合：跨班/跨日故障保留真实起止，班日志按重叠时间裁切展示。
            '仍在运行的故障在报告里标记"未恢复"，其结束时间在真正恢复时落表。
            snap.EndTime = endT
            snap.IsClosed = True
            FlushReport(snap, endT, True)
            SaveState(snap)
        End Sub

        ''' <summary>节流刷新日志文件（force=False 时按 ReportRefreshSeconds 节流）</summary>
        Private Sub FlushReport(snap As ShiftSnapshot, nowTime As Date, force As Boolean)
            If snap Is Nothing OrElse Not snap.HasData Then Return
            '待开班快照只承载故障记录，不生成班日志文件
            If Not _config.IsReportableShift(snap.Key) Then Return
            If Not force AndAlso snap.LastFlushTime <> Date.MinValue Then
                If (nowTime - snap.LastFlushTime).TotalSeconds < _options.ReportRefreshSeconds Then Return
            End If
            Dim text = BuildShiftReport(snap, nowTime)
            _fs.WriteAllTextAtomic(_paths.ShiftLogFile(snap.Key), text)
            snap.LastFlushTime = nowTime
        End Sub

        ''' <summary>生成班施工日志文本（模板化、按实际工序名分组，配置改名即可对齐甲方表格）</summary>
        Private Function BuildShiftReport(snap As ShiftSnapshot, viewTime As Date) As String
            Dim sb As New StringBuilder
            Dim key = snap.Key
            Dim winStart = _config.GetShiftFixedStart(key)
            Dim winEnd = If(snap.EndTime.HasValue, snap.EndTime.Value, viewTime)
            If winEnd < winStart Then winEnd = winStart

            sb.AppendLine("==============================================")
            sb.AppendLine("                班施工日志")
            sb.AppendLine(String.Format("日志日期：{0:yyyy-MM-dd}            班次：{1}", key.LogDate, key.ShiftName))
            sb.AppendLine(String.Format("当班进尺：{0:F2} m", snap.AdvanceM))
            sb.AppendLine("==============================================")
            sb.AppendLine("【生产情况记录】")

            '工序统计（按工序名称聚合；按显示宽度对齐，中文列不错位）
            Dim aggregates = AggregateProcesses(snap, winEnd)
            Dim aggWidths As Integer() = New Integer() {6, 20, 8, 21, 21, 12}
            sb.AppendLine(ReportText.Row(aggWidths, New String() {"序号", "项目", "次数", "首次开始时间", "最后结束时间", "累计耗时"}, True))
            sb.AppendLine("------------------------------------------------------------------------------")
            Dim idx As Integer = 1
            For Each agg In aggregates
                Dim lastEndText = "进行中"
                If agg.LastEnd.HasValue Then lastEndText = agg.LastEnd.Value.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)
                sb.AppendLine(ReportText.Row(aggWidths, New String() {
                    idx.ToString(CultureInfo.InvariantCulture), agg.Name, agg.Count.ToString(CultureInfo.InvariantCulture),
                    agg.FirstStart.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                    lastEndText, agg.TotalMinutes.ToString("F2", CultureInfo.InvariantCulture)}, True))
                idx += 1
            Next
            If aggregates.Count = 0 Then sb.AppendLine("（暂无工序记录）")

            '锚护数量折算（需求：一个锚护工序 = 顶锚杆5 + 帮锚杆6 + 锚索2）
            Dim supportCount = CountCategory(snap, ProcessCategory.Support)
            If supportCount > 0 Then
                sb.AppendLine("")
                sb.AppendLine("【锚护数量折算】")
                sb.AppendLine(String.Format("锚护工序次数：{0} 次", supportCount.ToString(CultureInfo.InvariantCulture)))
                sb.AppendLine(String.Format("顶锚杆：{0} 根（{1} 根/次）", (supportCount * _options.SupportRoofBolts).ToString(CultureInfo.InvariantCulture), _options.SupportRoofBolts.ToString(CultureInfo.InvariantCulture)))
                sb.AppendLine(String.Format("帮锚杆：{0} 根（{1} 根/次）", (supportCount * _options.SupportSideBolts).ToString(CultureInfo.InvariantCulture), _options.SupportSideBolts.ToString(CultureInfo.InvariantCulture)))
                sb.AppendLine(String.Format("锚索：{0} 根（{1} 根/次）", (supportCount * _options.SupportCables).ToString(CultureInfo.InvariantCulture), _options.SupportCables.ToString(CultureInfo.InvariantCulture)))
            End If

            '工序明细（时间顺序）
            sb.AppendLine("")
            sb.AppendLine("【工序明细】")
            Dim detailWidths As Integer() = New Integer() {6, 20, 21, 21, 12}
            sb.AppendLine(ReportText.Row(detailWidths, New String() {"序号", "工序名称", "开始时间", "结束时间", "耗时(分钟)"}, True))
            sb.AppendLine("------------------------------------------------------------------------------")
            If snap.ProcessList.Count = 0 Then
                sb.AppendLine("（暂无工序记录）")
            Else
                Dim i As Integer = 1
                For Each rec In snap.ProcessList
                    Dim endText = "进行中"
                    Dim cost = If(rec.IsClosed, rec.DurationMinute, If(viewTime > rec.StartTime, (viewTime - rec.StartTime).TotalMinutes, 0))
                    If rec.EndTime.HasValue Then endText = rec.EndTime.Value.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)
                    sb.AppendLine(ReportText.Row(detailWidths, New String() {
                        i.ToString(CultureInfo.InvariantCulture), rec.Name,
                        rec.StartTime.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                        endText, cost.ToString("F2", CultureInfo.InvariantCulture)}, True))
                    i += 1
                Next
            End If

            '设备故障（按班次时间窗裁切展示，真实起止不篡改）
            sb.AppendLine("")
            sb.AppendLine("【设备故障】")
            Dim faultWidths As Integer() = New Integer() {28, 21, 21, 13}
            sb.AppendLine(ReportText.Row(faultWidths, New String() {"故障ID-描述", "开始时间", "结束时间", "耗时(分钟)"}, True) & "  说明")
            sb.AppendLine("------------------------------------------------------------------------------")
            Dim faults = CollectFaultsForWindow(snap, winStart, winEnd)
            If faults.Count = 0 Then
                sb.AppendLine("（本班次无故障记录）")
            Else
                For Each item In faults
                    Dim rec = item.Record
                    Dim note As New StringBuilder
                    If rec.IsRunning Then note.Append("未恢复 ")
                    If item.ClipStart > rec.StartTime Then note.Append("故障跨班，本班从班次开始计 ")
                    If rec.EndTime.HasValue AndAlso item.ClipEnd < rec.EndTime.Value Then note.Append("延续至下班的故障，本班裁切 ")
                    sb.AppendLine(ReportText.Row(faultWidths, New String() {
                        "[" & rec.FaultId.ToString(CultureInfo.InvariantCulture) & "]" & rec.FaultDesc,
                        item.ClipStart.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                        item.ClipEnd.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                        item.Minutes.ToString("F2", CultureInfo.InvariantCulture)}, True) & "  " & note.ToString().Trim())
                Next
            End If

            sb.AppendLine("")
            sb.AppendLine("【生产存在问题】")
            sb.AppendLine("（现场填写）")
            sb.AppendLine("")
            sb.AppendLine("【矿方影响】")
            sb.AppendLine("（现场填写）")
            sb.AppendLine("")
            sb.AppendLine("==============================================")
            sb.AppendLine(String.Format("班次开始时间：{0:yyyy-MM-dd HH:mm:ss}", winStart))
            If snap.EndTime.HasValue Then
                sb.AppendLine(String.Format("班次结束时间：{0:yyyy-MM-dd HH:mm:ss}", snap.EndTime.Value))
            Else
                sb.AppendLine("班次结束时间：进行中")
            End If
            sb.AppendLine(String.Format("当班进尺：{0:F2} m", snap.AdvanceM))
            sb.AppendLine(String.Format("日志状态：{0}", If(snap.IsClosed, "已收尾", "进行中（可随时拷贝，不占用文件）")))
            sb.AppendLine(String.Format("生成时间：{0:yyyy-MM-dd HH:mm:ss}", Date.Now))
            Return sb.ToString()
        End Function

        ''' <summary>按工序名称聚合：次数、首次开始、最后结束、累计耗时</summary>
        Private Function AggregateProcesses(snap As ShiftSnapshot, viewTime As Date) As List(Of ProcessAggregate)
            Dim map As New Dictionary(Of String, ProcessAggregate)
            Dim order As New List(Of ProcessAggregate)
            For Each rec In snap.ProcessList
                Dim agg As ProcessAggregate = Nothing
                If Not map.TryGetValue(rec.Name, agg) Then
                    agg = New ProcessAggregate With {.Name = rec.Name}
                    map(rec.Name) = agg
                    order.Add(agg)
                End If
                agg.Count += 1
                If agg.FirstStart = Date.MinValue OrElse rec.StartTime < agg.FirstStart Then agg.FirstStart = rec.StartTime
                Dim recEnd = If(rec.EndTime.HasValue, rec.EndTime.Value, viewTime)
                If Not agg.LastEnd.HasValue OrElse recEnd > agg.LastEnd.Value Then agg.LastEnd = recEnd
                agg.TotalMinutes += If(rec.IsClosed, rec.DurationMinute, If(viewTime > rec.StartTime, (viewTime - rec.StartTime).TotalMinutes, 0))
            Next
            Return order
        End Function

        Private Function CountCategory(snap As ShiftSnapshot, category As ProcessCategory) As Integer
            Dim count As Integer = 0
            For Each rec In snap.ProcessList
                If rec.Category = category Then count += 1
            Next
            Return count
        End Function

        ''' <summary>收集与班次时间窗有重叠的故障（含相邻班次快照，按故障同一性去重）</summary>
        Private Function CollectFaultsForWindow(snap As ShiftSnapshot, fromTime As Date, toTime As Date) As List(Of FaultWindowItem)
            Dim result As New List(Of FaultWindowItem)
            Dim seen As New HashSet(Of String)
            Dim day = snap.Key.LogDate
            For Each offset In New Integer() {-1, 0, 1}
                For Each shift In New WorkShift() {WorkShift.Morning, WorkShift.Noon, WorkShift.None}
                    Dim other = GetSnapshotCore(New ShiftKey(day.AddDays(offset), shift))
                    If other Is Nothing Then Continue For
                    For Each ft In other.FaultList
                        Dim clipStart As Date
                        Dim clipEnd As Date
                        If Not ft.ClipTo(fromTime, toTime, clipStart, clipEnd) Then Continue For
                        Dim signature = ft.FaultId.ToString(CultureInfo.InvariantCulture) & "|" & ft.StartTime.ToString("yyyyMMddHHmmss", CultureInfo.InvariantCulture)
                        If Not seen.Add(signature) Then Continue For
                        result.Add(New FaultWindowItem With {
                            .Record = ft,
                            .ClipStart = clipStart,
                            .ClipEnd = clipEnd
                        })
                    Next
                Next
            Next
            result.Sort(AddressOf CompareFaultWindowItem)
            Return result
        End Function

        Private Shared Function CompareFaultWindowItem(a As FaultWindowItem, b As FaultWindowItem) As Integer
            Return Date.Compare(a.ClipStart, b.ClipStart)
        End Function

        ''' <summary>工序聚合行</summary>
        Private Class ProcessAggregate
            Public Property Name As String
            Public Property Count As Integer
            Public Property FirstStart As Date = Date.MinValue
            Public Property LastEnd As Date?
            Public Property TotalMinutes As Double
        End Class

        ''' <summary>故障时间窗展示行</summary>
        Private Class FaultWindowItem
            Public Property Record As FaultRecord
            Public Property ClipStart As Date
            Public Property ClipEnd As Date

            Public ReadOnly Property Minutes As Double
                Get
                    Dim v = (ClipEnd - ClipStart).TotalMinutes
                    If v < 0 Then Return 0
                    Return v
                End Get
            End Property
        End Class

    End Class

End Namespace
