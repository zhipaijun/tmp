﻿Option Explicit On
Option Strict Off
Option Infer On
'==============================================================================
' 文件：ConstructionLogService.vb
' 作用：施工日志统一入口（组合班/日/月日志管理器，处理采集事件、跨日跨月切换、
'       下位机标志位握手、异常隔离）
'
' 建议集成方式（PLC 主循环）：
'   1) 上电/首次送电        → Service.OnPowerOn(now)
'   2) CAN 工序报文         → Service.UpdateProcessInfo(now, procCode, advanceM)
'   3) CAN 油泵状态         → Service.CheckOilMtrStatus(now, mtr1Run, mtr2Run)
'   4) CAN 故障报文         → Service.CheckFaultStatus(now, faultId, faultFlag)
'   5) 周期调用（建议 1s）  → Service.Tick(now)
'   6) 正常停机             → Service.OnPowerOff(now)
' 所有方法内部捕获异常（写入 LastError 并触发 ErrorOccurred 事件），不向采集主循环抛异常。
'==============================================================================

Imports System
Imports System.Collections.Generic
Imports System.Globalization
Imports System.IO

Namespace Ebm.ConstructionLog

    ''' <summary>日志操作异常事件参数</summary>
    Public Class LogErrorEventArgs
        Inherits EventArgs

        Private ReadOnly _operation As String
        Private ReadOnly _error As Exception

        Public ReadOnly Property Operation As String
            Get
                Return _operation
            End Get
        End Property

        Public ReadOnly Property [Error] As Exception
            Get
                Return _error
            End Get
        End Property

        Public Sub New(operation As String, ex As Exception)
            _operation = operation
            _error = ex
        End Sub

        Public Overrides Function ToString() As String
            Return Operation & "：" & If([Error] Is Nothing, "", [Error].Message)
        End Function
    End Class

    ''' <summary>施工日志服务（对外唯一入口，线程安全）</summary>
    Public Class ConstructionLogService
        Private ReadOnly _config As LogConfig
        Private ReadOnly _options As LogOptions
        Private ReadOnly _paths As LogPaths
        Private ReadOnly _fs As LogFileSystem
        Private ReadOnly _tables As RecordTables
        Private ReadOnly _plc As IPlcIo
        Private ReadOnly _shiftMgr As ShiftLogManager
        Private ReadOnly _dailyMgr As DailyLogManager
        Private ReadOnly _monthlyMgr As MonthlyLogManager
        Private ReadOnly _gate As New Object()
        Private _currentDay As Date?
        Private _noonResetPending As Boolean
        Private _lastError As String

        ''' <summary>日志写入/生成异常（已隔离，不中断采集）</summary>
        Public Event ErrorOccurred As EventHandler(Of LogErrorEventArgs)

        Public Sub New(config As LogConfig, plc As IPlcIo)
            If config Is Nothing Then Throw New ArgumentNullException("config")
            _config = config
            _options = config.Options
            _plc = If(plc, New NullPlcIo())
            _fs = New LogFileSystem(_options)
            _paths = New LogPaths(_options.LogRootPath)
            _fs.EnsureAllDirectories(_paths)
            _tables = New RecordTables(_fs, _paths)
            Dim stateStore = New ShiftStateStore(_fs, _paths)
            _shiftMgr = New ShiftLogManager(config, _fs, _paths, stateStore, _tables)
            _dailyMgr = New DailyLogManager(config, _fs, _paths, _tables, _plc, _shiftMgr)
            _monthlyMgr = New MonthlyLogManager(config, _fs, _paths, _tables)
        End Sub

        ''' <summary>日志根目录</summary>
        Public ReadOnly Property RootPath As String
            Get
                Return _paths.RootPath
            End Get
        End Property

        ''' <summary>最近一次被隔离的异常描述（正常为 Nothing）</summary>
        Public ReadOnly Property LastError As String
            Get
                Return _lastError
            End Get
        End Property

        ''' <summary>程序启动初始化：确保目录存在、确定待补生成的日期</summary>
        Public Sub OnProgramStart()
            SafeExecute(Sub()
                            _fs.EnsureAllDirectories(_paths)
                            If Not _currentDay.HasValue Then _currentDay = GetLastActivityDay(Date.Now)
                        End Sub, "程序启动初始化")
        End Sub

        ''' <summary>设备第一次（或每次）送电</summary>
        Public Sub OnPowerOn(nowTime As Date)
            SafeExecute(Sub()
                            TickCore(nowTime)
                            _shiftMgr.OnPowerOn(nowTime)
                        End Sub, "送电处理")
        End Sub

        ''' <summary>CAN 报文：工序 + 当班进尺（advanceM 传 -1 时改从 IPlcIo.ReadShiftAdvanceM 读取）</summary>
        Public Sub UpdateProcessInfo(nowTime As Date, procCode As Integer, advanceM As Double)
            SafeExecute(Sub()
                            '先处理班次边界（例如 16:00 整点先把早班收尾，再写入中班第一工序）
                            TickCore(nowTime)
                            '中班日志完成 → 下发工序归零 → 工序为 0 时清除标志位
                            If _noonResetPending AndAlso procCode = 0 Then
                                _plc.WriteShiftLogDoneFlag(WorkShift.Noon, False)
                                _noonResetPending = False
                            End If
                            '当班进尺：CAN 参数 >= 0 时使用 CAN 值；传 -1 表示由 IPlcIo 读取下位机掉电保存变量
                            Dim advance = advanceM
                            If advance < 0 Then advance = _plc.ReadShiftAdvanceM()
                            _shiftMgr.UpdateProcessInfo(nowTime, procCode, advance)
                        End Sub, "工序报文处理")
        End Sub

        ''' <summary>CAN 报文：油泵状态（中班泵停触发中班收尾，并释放日志占用）</summary>
        Public Sub CheckOilMtrStatus(nowTime As Date, mtr1Run As Boolean, mtr2Run As Boolean)
            SafeExecute(Sub()
                            TickCore(nowTime)
                            Dim closedKey = _shiftMgr.CheckOilMtrStatus(nowTime, mtr1Run, mtr2Run)
                            If closedKey IsNot Nothing Then
                                ApplyShiftClosedFlags(closedKey)
                            End If
                            EnsureDayRollover(nowTime)
                        End Sub, "油泵状态处理")
        End Sub

        ''' <summary>CAN 报文：多路故障状态</summary>
        Public Sub CheckFaultStatus(nowTime As Date, faultId As Integer, faultFlag As Boolean)
            SafeExecute(Sub()
                            TickCore(nowTime)
                            _shiftMgr.CheckFaultStatus(nowTime, faultId, faultFlag)
                        End Sub, "故障报文处理")
        End Sub

        ''' <summary>周期调用（建议 1 秒）：班次边界收尾 + 跨日生成日/月日志 + 日志节流刷新</summary>
        Public Sub Tick(nowTime As Date)
            SafeExecute(Sub()
                            TickCore(nowTime)
                        End Sub, "周期处理")
        End Sub

        ''' <summary>正常停机：收尾当前班次、关闭运行中故障</summary>
        Public Sub OnPowerOff(nowTime As Date)
            SafeExecute(Sub()
                            Dim closedKeys = _shiftMgr.OnPowerOff(nowTime)
                            For Each key In closedKeys
                                ApplyShiftClosedFlags(key)
                            Next
                            EnsureDayRollover(nowTime)
                        End Sub, "停机处理")
        End Sub

        '==================================================================
        ' 查询/手工操作（测试、补生成、现场维护）
        '==================================================================
        Public Function IsShiftClosed(day As Date, shift As WorkShift) As Boolean
            Return _shiftMgr.IsShiftClosed(New ShiftKey(day, shift))
        End Function

        Public Function IsAllOilMtrStop(day As Date) As Boolean
            Return _shiftMgr.IsAllOilMtrStop(day)
        End Function

        ''' <summary>手工生成/重生成某日日施工日志（数据不足时返回 Nothing）</summary>
        Public Function ForceGenerateDailyLog(day As Date, generatedAt As Date) As DailySummary
            Try
                SyncLock _gate
                    If Not _dailyMgr.HasDayData(day) Then Return Nothing
                    '需求：日施工日志在"跨日后"生成上一日日志。当日（含当晚中班未开始/未结束）禁止手工提前生成，
                    '否则会把中班尚未发生的数据以 0 固化进日汇总表。
                    If day.Date >= generatedAt.Date Then
                        _lastError = "手工生成日日志被拒绝：日施工日志须跨日后生成（请求日=" & day.ToString("yyyy-MM-dd") & "）"
                        Return Nothing
                    End If
                    If Not _shiftMgr.IsDayClosed(day) Then
                        _lastError = "手工生成日日志被拒绝：该日班次尚未全部收尾（" & day.ToString("yyyy-MM-dd") & "）"
                        Return Nothing
                    End If
                    '已落过日汇总：用汇总重渲染文本（保证文本/表/月统计一致，且不会被 PLC 当前计数污染）
                    Dim existing = _tables.ReadDailySummary(day)
                    If existing IsNot Nothing Then
                        _dailyMgr.WriteReportFromSummary(existing)
                        _monthlyMgr.UpdateMonth(day)
                        Return existing
                    End If
                    Dim summary = _dailyMgr.GenerateDailyLog(day, generatedAt)
                    _monthlyMgr.UpdateMonth(day)
                    ApplyDailyGeneratedFlags()
                    Return summary
                End SyncLock
            Catch ex As Exception
                ReportError("手工生成日日志", ex)
                Return Nothing
            End Try
        End Function

        ''' <summary>读取班施工日志文本（现场查看/导出）</summary>
        Public Function BuildShiftReportText(day As Date, shift As WorkShift) As String
            Return _shiftMgr.BuildShiftReportText(New ShiftKey(day, shift))
        End Function

        '==================================================================
        ' 内部：核心流程
        '==================================================================
        Private Sub TickCore(nowTime As Date)
            SyncLock _gate
                '1) 班次固定边界/泵停边界收尾
                Dim closedKeys = _shiftMgr.Tick(nowTime)
                For Each key In closedKeys
                    ApplyShiftClosedFlags(key)
                Next
                '2) 跨日：补生成上一日（及停机期间遗漏日期）的日/月日志
                EnsureDayRollover(nowTime)
            End SyncLock
        End Sub

        ''' <summary>
        ''' 跨日处理：把已收尾日期的日施工日志生成出来，再更新月施工日志。
        ''' 中班若仍在运行（泵启未停），则等待其收尾后再生成，避免数据不全。
        ''' </summary>
        Private Sub EnsureDayRollover(nowTime As Date)
            SyncLock _gate
                If Not _currentDay.HasValue Then _currentDay = GetLastActivityDay(nowTime)
                '时钟回拨（NTP 校时/BIOS 电池失效）后，允许回退补生成，避免日/月日志永久停摆
                If _currentDay.Value > nowTime.Date Then
                    _currentDay = nowTime.Date.AddDays(-1)
                End If
                Dim guard As Integer = 0
                While _currentDay.Value < nowTime.Date AndAlso guard < 3660
                    guard += 1
                    Dim day = _currentDay.Value

                    '把该日仍未收尾的班次按边界收尾（中班若泵仍在运行则不收，等待）
                    Dim closedKeys = _shiftMgr.FinalizeDayShifts(day, nowTime)
                    For Each key In closedKeys
                        ApplyShiftClosedFlags(key)
                    Next

                    If Not _shiftMgr.IsDayClosed(day) Then
                        '中班跨日泵未停，等泵停后再生成
                        Return
                    End If

                    If _dailyMgr.HasDayData(day) Then
                        '已落过日汇总表（例如生成后重启、时钟回拨后重扫）只重算月日志，不重复生成日日志：
                        '避免用 PLC 当前计数回写历史日期。
                        If Not _tables.IsDailySummaryExists(day) Then
                            _dailyMgr.GenerateDailyLog(day, nowTime)
                            ApplyDailyGeneratedFlags()
                        Else
                            '文本缺失/过期时用已落表汇总自愈，避免日日志文件丢失
                            _dailyMgr.EnsureDailyReportFile(day)
                        End If
                        _monthlyMgr.UpdateMonth(day)
                    End If
                    '清理已归档日期的内存快照（数据文件保留）
                    _shiftMgr.EvictSnapshotsBefore(day.AddDays(1))
                    _currentDay = day.AddDays(1)
                End While
            End SyncLock
        End Sub

        ''' <summary>班次收尾后的下位机标志位下发</summary>
        Private Sub ApplyShiftClosedFlags(key As ShiftKey)
            _plc.WriteShiftLogDoneFlag(key.Shift, True)
            If key.Shift = WorkShift.Noon Then
                '需求：中班日志生成完成后下发标志位，工序归零；工序为零则置 false
                _noonResetPending = True
                _plc.RequestProcessReset()
            End If
        End Sub

        ''' <summary>日施工日志生成完成后的标志位处理：日完成 → 班次记录标志清零</summary>
        Private Sub ApplyDailyGeneratedFlags()
            _plc.WriteDailyLogDoneFlag(True)
            _plc.WriteShiftLogDoneFlag(WorkShift.Morning, False)
            _plc.WriteShiftLogDoneFlag(WorkShift.Noon, False)
            _plc.WriteDailyLogDoneFlag(False)
            _noonResetPending = False
        End Sub

        ''' <summary>最近活动日期：用于重启后补生成停机期间遗漏的日日志</summary>
        Private Function GetLastActivityDay(nowTime As Date) As Date
            Try
                Dim maxDate = Date.MinValue
                If Directory.Exists(_paths.DataDir) Then
                    For Each file In Directory.GetFiles(_paths.DataDir, "shift_state_*.tsv")
                        Dim name = Path.GetFileNameWithoutExtension(file)
                        Dim parts = name.Split(New Char() {"_"c})
                        If parts.Length >= 3 Then
                            Dim d As Date
                            If Date.TryParseExact(parts(2), "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, d) Then
                                If d > maxDate Then maxDate = d
                            End If
                        End If
                    Next
                End If
                If maxDate <> Date.MinValue Then
                    '若最近活动日就是"今天"（或时钟比持久化日期更早），补生成起点取昨天，
                    '避免"昨日日日志尚未生成但今天已有状态文件"时被跳过
                    If maxDate >= nowTime.Date Then Return nowTime.Date.AddDays(-1)
                    Return maxDate
                End If
            Catch ex As Exception
                '扫描失败时退回"昨天"，不影响启动
            End Try
            Return nowTime.Date.AddDays(-1)
        End Function

        Private Sub SafeExecute(action As Action, operation As String)
            Try
                action()
                _lastError = Nothing
            Catch ex As Exception
                ReportError(operation, ex)
            End Try
        End Sub

        Private Sub ReportError(operation As String, ex As Exception)
            _lastError = operation & "：" & ex.Message
            Try
                RaiseEvent ErrorOccurred(Me, New LogErrorEventArgs(operation, ex))
            Catch ex2 As Exception
                '事件订阅方异常不影响采集
            End Try
        End Sub

    End Class

End Namespace
