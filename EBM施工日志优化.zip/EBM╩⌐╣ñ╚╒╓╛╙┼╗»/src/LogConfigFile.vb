﻿'==============================================================================
' 文件：LogConfigFile.vb
' 作用：从文本配置文件加载现场参数（班次边界、锚护折算系数、故障过滤白名单、
'       工序名称覆盖等），避免改一个参数就要重新编译程序。
'
' 配置格式（每行 key=value，# 或 ; 开头为注释）：
'   LogRootPath=D:\EbmLogs
'   MorningStartHour=8
'   MorningEndHour=16
'   NoonStartHour=16
'   NoonMaxCarryOverHours=8
'   ReportRefreshSeconds=30
'   SupportRoofBolts=5
'   SupportSideBolts=6
'   SupportCables=2
'   SplitSupportDurationByRatio=true
'   OnlyCountProductionFaults=false
'   TextEncodingName=GB18030
'   fault.counted.2=false          '按需屏蔽不影响生产的故障
'   process.10=锚护               '工序名称覆盖（可与甲方模板行名对齐）
'==============================================================================

Imports System
Imports System.Globalization
Imports System.IO
Imports System.Text

Namespace Ebm.ConstructionLog

    ''' <summary>日志配置文件解析器</summary>
    Public NotInheritable Class LogConfigFile
        Private Sub New()
        End Sub

        ''' <summary>把配置文件中的参数覆盖到已有配置对象上（文件不存在时保持默认值）</summary>
        Public Shared Sub Apply(path As String, config As LogConfig)
            If config Is Nothing Then Throw New ArgumentNullException("config")
            If String.IsNullOrEmpty(path) OrElse Not File.Exists(path) Then Return
            For Each rawLine In ReadAllLinesSmart(path)
                Dim line = rawLine.Trim()
                If line.Length = 0 OrElse line.StartsWith("#") OrElse line.StartsWith(";") Then Continue For
                Dim idx = line.IndexOf("="c)
                If idx <= 0 Then Continue For
                Dim key = line.Substring(0, idx).Trim()
                Dim value = line.Substring(idx + 1).Trim()
                ApplyOne(key, value, config)
            Next
        End Sub

        ''' <summary>读取配置（UTF-8 优先，失败回退 GB18030，兼容现场记事本另存）</summary>
        Private Shared Function ReadAllLinesSmart(path As String) As String()
            Try
                Dim utf8Strict As New UTF8Encoding(False, True)
                Return File.ReadAllLines(path, utf8Strict)
            Catch ex As DecoderFallbackException
                Return File.ReadAllLines(path, Encoding.GetEncoding("GB18030"))
            Catch ex As Exception
                Return New String() {}
            End Try
        End Function

        Private Shared Sub ApplyOne(key As String, value As String, config As LogConfig)
            Dim o = config.Options
            Dim lower = key.ToLowerInvariant()
            Select Case lower
                Case "logrootpath"
                    o.LogRootPath = value
                Case "morningstarthour"
                    o.MorningStartHour = ParseInt(value, o.MorningStartHour)
                Case "morningendhour"
                    o.MorningEndHour = ParseInt(value, o.MorningEndHour)
                Case "noonstarthour"
                    o.NoonStartHour = ParseInt(value, o.NoonStartHour)
                Case "noonmaxcarryoverhours"
                    o.NoonMaxCarryOverHours = ParseInt(value, o.NoonMaxCarryOverHours)
                Case "noonpumpstopdebounceseconds"
                    o.NoonPumpStopDebounceSeconds = ParseInt(value, o.NoonPumpStopDebounceSeconds)
                Case "reportrefreshseconds"
                    o.ReportRefreshSeconds = ParseInt(value, o.ReportRefreshSeconds)
                Case "supportroofbolts"
                    o.SupportRoofBolts = ParseInt(value, o.SupportRoofBolts)
                Case "supportsidebolts"
                    o.SupportSideBolts = ParseInt(value, o.SupportSideBolts)
                Case "supportcables"
                    o.SupportCables = ParseInt(value, o.SupportCables)
                Case "splitsupportdurationbyratio"
                    o.SplitSupportDurationByRatio = ParseBool(value, o.SplitSupportDurationByRatio)
                Case "onlycountproductionfaults"
                    o.OnlyCountProductionFaults = ParseBool(value, o.OnlyCountProductionFaults)
                Case "textencodingname"
                    If value.Length > 0 Then o.TextEncodingName = value
                Case Else
                    'fault.counted.<id>=true/false
                    If lower.StartsWith("fault.counted.") Then
                        Dim idText = key.Substring("fault.counted.".Length)
                        Dim id As Integer
                        If Integer.TryParse(idText, NumberStyles.Integer, CultureInfo.InvariantCulture, id) Then
                            config.GetFault(id).IsProductionAffecting = ParseBool(value, True)
                        End If
                        Return
                    End If
                    'process.<code>=工序名称（用于与甲方日志模板行名对齐）
                    If lower.StartsWith("process.") Then
                        Dim codeText = key.Substring("process.".Length)
                        Dim code As Integer
                        If Integer.TryParse(codeText, NumberStyles.Integer, CultureInfo.InvariantCulture, code) Then
                            config.GetProcess(code).Name = value
                        End If
                        Return
                    End If
            End Select
        End Sub

        Private Shared Function ParseInt(value As String, fallback As Integer) As Integer
            Dim v As Integer
            If Integer.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, v) Then Return v
            Return fallback
        End Function

        Private Shared Function ParseBool(value As String, fallback As Boolean) As Boolean
            Dim v As Boolean
            If Boolean.TryParse(value, v) Then Return v
            '兼容 1/0、是/否、yes/no、on/off
            If value = "1" OrElse value = "是" OrElse value.Equals("yes", StringComparison.OrdinalIgnoreCase) OrElse value.Equals("on", StringComparison.OrdinalIgnoreCase) Then Return True
            If value = "0" OrElse value = "否" OrElse value.Equals("no", StringComparison.OrdinalIgnoreCase) OrElse value.Equals("off", StringComparison.OrdinalIgnoreCase) Then Return False
            Return fallback
        End Function

    End Class

End Namespace
