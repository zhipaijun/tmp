﻿Option Explicit On
Option Strict Off
Option Infer On
'==============================================================================
' 文件：LogInfrastructure.vb
' 作用：日志路径规划、安全文件读写（不长期占用文件句柄）、班次状态持久化、
'       "单独建表"的工序/故障/日汇总明细表
' 设计要点：
'   1) 所有日志采用"整写/追加 + 立即关闭"，绝不长期持有 FileStream —— 满足
'      需求"日志占用问题：考虑日志拷出问题，不要一直占用"；
'   2) 班次状态落盘为快照，断电重启后可从状态文件恢复未结束工序/未恢复故障；
'   3) 工序表、故障表、日汇总表均为追加式 TSV，供日/月日志累计统计。
'==============================================================================

Imports System
Imports System.Collections.Generic
Imports System.Globalization
Imports System.IO
Imports System.Text
Imports System.Threading

Namespace Ebm.ConstructionLog

    ''' <summary>日志 IO 异常（重试后仍失败时抛出，由上层统一记录，不中断采集主循环）</summary>
    Public Class LogIoException
        Inherits Exception

        Public Sub New(message As String, inner As Exception)
            MyBase.New(message, inner)
        End Sub
    End Class

    ''' <summary>日志目录与文件命名规划（命名规则严格按需求）</summary>
    Public Class LogPaths
        Private ReadOnly _rootPath As String
        Private ReadOnly _logDir As String
        Private ReadOnly _dataDir As String

        Public Sub New(rootPath As String)
            If String.IsNullOrEmpty(rootPath) Then Throw New ArgumentNullException("rootPath")
            _rootPath = rootPath
            _logDir = Path.Combine(rootPath, "Logs")
            _dataDir = Path.Combine(rootPath, "Data")
        End Sub

        Public ReadOnly Property RootPath As String
            Get
                Return _rootPath
            End Get
        End Property

        Public ReadOnly Property LogDir As String
            Get
                Return _logDir
            End Get
        End Property

        Public ReadOnly Property DataDir As String
            Get
                Return _dataDir
            End Get
        End Property

        ''' <summary>班施工日志-日期（yyMMdd）-早班/中班.txt</summary>
        Public Function ShiftLogFile(key As ShiftKey) As String
            Return Path.Combine(LogDir, "班施工日志-" & key.ShortDateText & "-" & key.ShiftName & ".txt")
        End Function

        ''' <summary>日施工日志-日期（yyMMdd）.txt</summary>
        Public Function DailyLogFile(day As Date) As String
            Return Path.Combine(LogDir, "日施工日志-" & day.ToString("yyMMdd", CultureInfo.InvariantCulture) & ".txt")
        End Function

        ''' <summary>月施工日志-日期（yyMM）.txt</summary>
        Public Function MonthlyLogFile(month As Date) As String
            Return Path.Combine(LogDir, "月施工日志-" & month.ToString("yyMM", CultureInfo.InvariantCulture) & ".txt")
        End Function

        ''' <summary>班次运行状态快照文件（掉电恢复用）</summary>
        Public Function ShiftStateFile(key As ShiftKey) As String
            Return Path.Combine(DataDir, "shift_state_" & key.CacheKey & ".tsv")
        End Function

        ''' <summary>工序明细表（日/月日志耗时累计的数据源）</summary>
        Public ReadOnly Property ProcessRecordsFile As String
            Get
                Return Path.Combine(DataDir, "process_records.tsv")
            End Get
        End Property

        ''' <summary>故障明细表（需求：故障日志单独建表维护）</summary>
        Public ReadOnly Property FaultRecordsFile As String
            Get
                Return Path.Combine(DataDir, "fault_records.tsv")
            End Get
        End Property

        ''' <summary>待开班时段送电时刻持久化文件（重启后仍能按送电时间起算第一个工序）</summary>
        Public ReadOnly Property PendingPowerOnFile As String
            Get
                Return Path.Combine(DataDir, "pending_poweron.txt")
            End Get
        End Property

        ''' <summary>日汇总表（日施工日志生成后落表，月施工日志数据源）</summary>
        Public ReadOnly Property DailySummaryFile As String
            Get
                Return Path.Combine(DataDir, "daily_summary.tsv")
            End Get
        End Property
    End Class

    ''' <summary>
    ''' 安全文件读写：统一编码、失败重试、原子写。
    ''' 全程 "打开-写入-关闭"，不保留句柄，保证日志可随时被拷贝/查看。
    ''' </summary>
    Public Class LogFileSystem
        Private ReadOnly _options As LogOptions
        Private ReadOnly _encoding As Encoding

        Public Sub New(options As LogOptions)
            _options = options
            _encoding = ResolveEncoding(options.TextEncodingName)
        End Sub

        Private Shared Function ResolveEncoding(name As String) As Encoding
            Try
                Return Encoding.GetEncoding(name)
            Catch ex As Exception
                'GB18030 不可用时退回系统默认编码，保证程序可运行
                Return Encoding.Default
            End Try
        End Function

        Public ReadOnly Property TextEncoding As Encoding
            Get
                Return _encoding
            End Get
        End Property

        Public Sub EnsureDirectory(path As String)
            Try
                If Not Directory.Exists(path) Then Directory.CreateDirectory(path)
            Catch ex As Exception
                Throw New LogIoException("创建目录失败：" & path, ex)
            End Try
        End Sub

        Public Sub EnsureAllDirectories(paths As LogPaths)
            EnsureDirectory(paths.RootPath)
            EnsureDirectory(paths.LogDir)
            EnsureDirectory(paths.DataDir)
        End Sub

        ''' <summary>尽力复制（备份用，失败不抛异常）</summary>
        Public Sub TryCopy(source As String, dest As String)
            Try
                If File.Exists(source) Then File.Copy(source, dest, True)
            Catch ex As Exception
            End Try
        End Sub

        Public Function FileExists(path As String) As Boolean
            Try
                Return File.Exists(path)
            Catch ex As Exception
                Return False
            End Try
        End Function

        ''' <summary>读取文本；文件不存在返回 Nothing</summary>
        Public Function ReadAllText(path As String) As String
            If Not File.Exists(path) Then Return Nothing
            Dim result As String = Nothing
            Retry(Sub()
                      result = File.ReadAllText(path, _encoding)
                  End Sub, "读取文件失败：" & path)
            Return result
        End Function

        ''' <summary>读取所有行；文件不存在返回空列表</summary>
        Public Function ReadAllLines(path As String) As List(Of String)
            Dim list As New List(Of String)
            If Not File.Exists(path) Then Return list
            Dim lines As String() = Nothing
            Retry(Sub()
                      lines = File.ReadAllLines(path, _encoding)
                  End Sub, "读取文件失败：" & path)
            If lines IsNot Nothing Then list.AddRange(lines)
            Return list
        End Function

        ''' <summary>追加一行（打开-追加-关闭，不占用文件）</summary>
        Public Sub AppendLine(path As String, line As String)
            Retry(Sub()
                      File.AppendAllText(path, line & Environment.NewLine, _encoding)
                  End Sub, "追加文件失败：" & path)
        End Sub

        ''' <summary>
        ''' 整文件原子写：先写同目录临时文件，再替换目标文件。
        ''' 目标文件在任意时刻都是完整内容，且写完后不保留句柄。
        ''' </summary>
        Public Sub WriteAllTextAtomic(filePath As String, content As String)
            Dim dir = System.IO.Path.GetDirectoryName(filePath)
            If Not String.IsNullOrEmpty(dir) Then EnsureDirectory(dir)
            Dim tmp = filePath & ".tmp"
            Retry(Sub()
                      File.WriteAllText(tmp, content, _encoding)
                      If File.Exists(filePath) Then
                          Try
                              File.Replace(tmp, filePath, Nothing)
                          Catch ex As IOException
                              '个别文件系统不支持 Replace，退化为覆盖拷贝
                              File.Copy(tmp, filePath, True)
                              File.Delete(tmp)
                          End Try
                      Else
                          File.Move(tmp, filePath)
                      End If
                  End Sub, "写入文件失败：" & filePath)
        End Sub

        Private Sub Retry(action As Action, message As String)
            Dim lastEx As Exception = Nothing
            Dim attempts = Math.Max(1, _options.IoRetryCount)
            For attempt As Integer = 1 To attempts
                Try
                    action()
                    Return
                Catch ex As IOException
                    lastEx = ex
                Catch ex As UnauthorizedAccessException
                    lastEx = ex
                End Try
                If attempt < attempts Then
                    Thread.Sleep(Math.Max(10, _options.IoRetryDelayMs))
                End If
            Next
            Throw New LogIoException(message, lastEx)
        End Sub
    End Class

    ''' <summary>
    ''' 班次状态快照持久化（TSV）。
    ''' 保存内容：班次元数据 + 全部工序 + 全部故障，重启后完整恢复，避免丢当班记录。
    ''' </summary>
    Public Class ShiftStateStore
        Private Const DATE_FORMAT As String = "yyyy-MM-dd HH:mm:ss"

        Private ReadOnly _fs As LogFileSystem
        Private ReadOnly _paths As LogPaths

        Public Sub New(fs As LogFileSystem, paths As LogPaths)
            _fs = fs
            _paths = paths
        End Sub

        Public Sub Save(snapshot As ShiftSnapshot)
            If snapshot Is Nothing Then Return
            Dim sb As New StringBuilder
            Dim k = snapshot.Key
            'S = Shift 元数据
            sb.AppendLine(String.Join("|", New String() {
                "S",
                k.LogDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                CInt(k.Shift).ToString(CultureInfo.InvariantCulture),
                snapshot.AdvanceM.ToString("F4", CultureInfo.InvariantCulture),
                BoolText(snapshot.OilPump1Run),
                BoolText(snapshot.OilPump2Run),
                BoolText(snapshot.PumpEverStarted),
                DateText(snapshot.PowerOnTime),
                DateText(snapshot.StartTime),
                DateText(snapshot.EndTime),
                BoolText(snapshot.IsClosed),
                snapshot.LastProcessCode.ToString(CultureInfo.InvariantCulture),
                DateText(snapshot.PumpStopCandidate)
            }))
            For Each p In snapshot.ProcessList
                'P = 工序记录
                sb.AppendLine(String.Join("|", New String() {
                    "P",
                    p.Code.ToString(CultureInfo.InvariantCulture),
                    Clean(p.Name),
                    CInt(p.Category).ToString(CultureInfo.InvariantCulture),
                    DateText(p.StartTime),
                    DateText(p.EndTime)
                }))
            Next
            For Each f In snapshot.FaultList
                'F = 故障记录
                sb.AppendLine(String.Join("|", New String() {
                    "F",
                    f.FaultId.ToString(CultureInfo.InvariantCulture),
                    Clean(f.FaultDesc),
                    DateText(f.StartTime),
                    DateText(f.EndTime)
                }))
            Next
            '写前保留上一版快照，便于半截/损坏时人工恢复
            _fs.TryCopy(_paths.ShiftStateFile(k), _paths.ShiftStateFile(k) & ".bak")
            _fs.WriteAllTextAtomic(_paths.ShiftStateFile(k), sb.ToString())
        End Sub

        ''' <summary>读取状态快照；不存在或内容损坏返回 Nothing（不抛异常，避免影响启动）</summary>
        Public Function Load(key As ShiftKey) As ShiftSnapshot
            Dim path = _paths.ShiftStateFile(key)
            If Not _fs.FileExists(path) Then Return Nothing
            Try
                Dim lines = _fs.ReadAllLines(path)
                Dim snapshot As ShiftSnapshot = Nothing
                For Each raw In lines
                    Dim line = raw.Trim()
                    If line.Length = 0 Then Continue For
                    Dim parts = line.Split(New Char() {"|"c})
                    If parts.Length = 0 Then Continue For
                    Select Case parts(0)
                        Case "S"
                            If parts.Length >= 12 Then
                                snapshot = New ShiftSnapshot With {
                                    .Key = New ShiftKey(Date.ParseExact(parts(1), "yyyy-MM-dd", CultureInfo.InvariantCulture), CType(Integer.Parse(parts(2), CultureInfo.InvariantCulture), WorkShift)),
                                    .AdvanceM = ParseDouble(parts(3)),
                                    .OilPump1Run = ParseBool(parts(4)),
                                    .OilPump2Run = ParseBool(parts(5)),
                                    .PumpEverStarted = ParseBool(parts(6)),
                                    .PowerOnTime = ParseNullableDate(parts(7)),
                                    .StartTime = ParseNullableDate(parts(8)),
                                    .EndTime = ParseNullableDate(parts(9)),
                                    .IsClosed = ParseBool(parts(10)),
                                    .LastProcessCode = Integer.Parse(parts(11), CultureInfo.InvariantCulture),
                                    .PumpStopCandidate = If(parts.Length >= 13, ParseNullableDate(parts(12)), Nothing)
                                }
                            End If
                        Case "P"
                            If snapshot IsNot Nothing AndAlso parts.Length >= 6 Then
                                Dim rec As New ProcessRecord With {
                                    .Code = Integer.Parse(parts(1), CultureInfo.InvariantCulture),
                                    .Name = parts(2),
                                    .Category = CType(Integer.Parse(parts(3), CultureInfo.InvariantCulture), ProcessCategory),
                                    .StartTime = ParseDate(parts(4)),
                                    .EndTime = ParseNullableDate(parts(5))
                                }
                                snapshot.ProcessList.Add(rec)
                            End If
                        Case "F"
                            If snapshot IsNot Nothing AndAlso parts.Length >= 5 Then
                                Dim rec As New FaultRecord With {
                                    .FaultId = Integer.Parse(parts(1), CultureInfo.InvariantCulture),
                                    .FaultDesc = parts(2),
                                    .StartTime = ParseDate(parts(3)),
                                    .EndTime = ParseNullableDate(parts(4))
                                }
                                snapshot.FaultList.Add(rec)
                            End If
                    End Select
                Next
                If snapshot Is Nothing Then
                    '文件存在但结构不完整（如掉电/拷贝中断导致半截）：改名 .bad 保留现场，返回 Nothing
                    Try
                        Dim badPath = path & ".bad"
                        If File.Exists(badPath) Then File.Delete(badPath)
                        File.Move(path, badPath)
                    Catch ex3 As Exception
                    End Try
                    Return Nothing
                End If
                snapshot.Key = key
                Return snapshot
            Catch ex As Exception
                '状态文件损坏：改名保留现场，返回 Nothing 让调用方按新班次处理，避免异常扩散
                Try
                    Dim badPath = path & ".bad"
                    If File.Exists(badPath) Then File.Delete(badPath)
                    File.Move(path, badPath)
                Catch ex2 As Exception
                End Try
                Return Nothing
            End Try
        End Function

        Private Shared Function Clean(value As String) As String
            If value Is Nothing Then Return ""
            '竖线是字段分隔符，出现的概率极低，做一次替换防御
            Return value.Replace("|", "/")
        End Function

        Private Shared Function BoolText(value As Boolean) As String
            If value Then Return "1" Else Return "0"
        End Function

        Private Shared Function ParseBool(text As String) As Boolean
            Return text = "1" OrElse String.Compare(text, "true", StringComparison.OrdinalIgnoreCase) = 0
        End Function

        Private Shared Function DateText(value As Date) As String
            Return value.ToString(DATE_FORMAT, CultureInfo.InvariantCulture)
        End Function

        Private Shared Function DateText(value As Date?) As String
            If Not value.HasValue Then Return ""
            Return value.Value.ToString(DATE_FORMAT, CultureInfo.InvariantCulture)
        End Function

        Private Shared Function ParseDate(text As String) As Date
            Return Date.ParseExact(text, DATE_FORMAT, CultureInfo.InvariantCulture)
        End Function

        Private Shared Function ParseNullableDate(text As String) As Date?
            If String.IsNullOrEmpty(text) Then Return Nothing
            Return ParseExactDate(text)
        End Function

        Private Shared Function ParseExactDate(text As String) As Date
            Return Date.ParseExact(text, DATE_FORMAT, CultureInfo.InvariantCulture)
        End Function

        Private Shared Function ParseDouble(text As String) As Double
            Dim v As Double = 0
            Double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, v)
            Return v
        End Function
    End Class

    ''' <summary>日汇总行（日施工日志落表结果，月施工日志数据源）</summary>
    Public Class DailySummary
        Public Property LogDate As Date
        Public Property AdvanceM As Double
        Public Property MorningCutCount As Integer
        Public Property MorningSupportCount As Integer
        Public Property MorningCutMinutes As Double
        Public Property MorningSupportMinutes As Double
        Public Property NoonCutCount As Integer
        Public Property NoonSupportCount As Integer
        Public Property NoonCutMinutes As Double
        Public Property NoonSupportMinutes As Double
        Public Property FaultMinutes As Double
        Public Property Remark As String
        Public Property GeneratedTime As Date
    End Class

    ''' <summary>
    ''' 明细表：工序表 / 故障表 / 日汇总表。
    ''' 追加写、按日期过滤读；这些表就是需求中"单独建表累计/维护"的数据载体。
    ''' </summary>
    Public Class RecordTables
        Private Const DT As String = "yyyy-MM-dd HH:mm:ss"
        Private Const ENC_DATE As String = "yyyyMMdd"

        Private ReadOnly _fs As LogFileSystem
        Private ReadOnly _paths As LogPaths

        Public Sub New(fs As LogFileSystem, paths As LogPaths)
            _fs = fs
            _paths = paths
        End Sub

        '------------------------------------------------------------------
        ' 工序明细表
        '------------------------------------------------------------------
        ''' <summary>追加一条已结束工序（工序切换/收尾时调用）</summary>
        Public Sub AppendProcess(day As Date, shift As WorkShift, record As ProcessRecord)
            If Not record.EndTime.HasValue Then Return
            Dim line = String.Join("|", New String() {
                day.ToString(ENC_DATE, CultureInfo.InvariantCulture),
                CInt(shift).ToString(CultureInfo.InvariantCulture),
                record.Code.ToString(CultureInfo.InvariantCulture),
                Clean(record.Name),
                CInt(record.Category).ToString(CultureInfo.InvariantCulture),
                record.StartTime.ToString(DT, CultureInfo.InvariantCulture),
                record.EndTime.Value.ToString(DT, CultureInfo.InvariantCulture),
                record.DurationMinute.ToString("F4", CultureInfo.InvariantCulture)
            })
            _fs.AppendLine(_paths.ProcessRecordsFile, line)
        End Sub

        ''' <summary>读取某日的全部工序明细</summary>
        Public Function ReadProcesses(day As Date) As List(Of ProcessRecord)
            Dim list As New List(Of ProcessRecord)
            Dim prefix = day.ToString(ENC_DATE, CultureInfo.InvariantCulture) & "|"
            For Each line In _fs.ReadAllLines(_paths.ProcessRecordsFile)
                If Not line.StartsWith(prefix, StringComparison.Ordinal) Then Continue For
                Dim parts = line.Split(New Char() {"|"c})
                If parts.Length < 8 Then Continue For
                Try
                    Dim rec As New ProcessRecord With {
                        .Code = Integer.Parse(parts(2), CultureInfo.InvariantCulture),
                        .Name = parts(3),
                        .Category = CType(Integer.Parse(parts(4), CultureInfo.InvariantCulture), ProcessCategory),
                        .Shift = CType(Integer.Parse(parts(1), CultureInfo.InvariantCulture), WorkShift),
                        .StartTime = Date.ParseExact(parts(5), DT, CultureInfo.InvariantCulture),
                        .EndTime = Date.ParseExact(parts(6), DT, CultureInfo.InvariantCulture)
                    }
                    list.Add(rec)
                Catch ex As Exception
                    '单行损坏跳过，不影响其他记录
                End Try
            Next
            Return list
        End Function

        '------------------------------------------------------------------
        ' 故障明细表（单独建表）
        '------------------------------------------------------------------
        ''' <summary>追加一条已结束故障（故障恢复/日收尾时调用）</summary>
        Public Sub AppendFault(day As Date, shift As WorkShift, record As FaultRecord)
            If Not record.EndTime.HasValue Then Return
            Dim line = String.Join("|", New String() {
                day.ToString(ENC_DATE, CultureInfo.InvariantCulture),
                CInt(shift).ToString(CultureInfo.InvariantCulture),
                record.FaultId.ToString(CultureInfo.InvariantCulture),
                Clean(record.FaultDesc),
                record.StartTime.ToString(DT, CultureInfo.InvariantCulture),
                record.EndTime.Value.ToString(DT, CultureInfo.InvariantCulture),
                record.DurationMinute.ToString("F4", CultureInfo.InvariantCulture)
            })
            _fs.AppendLine(_paths.FaultRecordsFile, line)
        End Sub

        ''' <summary>读取某日的全部故障明细</summary>
        Public Function ReadFaults(day As Date) As List(Of FaultRecord)
            Dim list As New List(Of FaultRecord)
            Dim prefix = day.ToString(ENC_DATE, CultureInfo.InvariantCulture) & "|"
            For Each line In _fs.ReadAllLines(_paths.FaultRecordsFile)
                If Not line.StartsWith(prefix, StringComparison.Ordinal) Then Continue For
                Dim parts = line.Split(New Char() {"|"c})
                If parts.Length < 7 Then Continue For
                Try
                    Dim rec As New FaultRecord With {
                        .FaultId = Integer.Parse(parts(2), CultureInfo.InvariantCulture),
                        .FaultDesc = parts(3),
                        .Shift = CType(Integer.Parse(parts(1), CultureInfo.InvariantCulture), WorkShift),
                        .StartTime = Date.ParseExact(parts(4), DT, CultureInfo.InvariantCulture),
                        .EndTime = Date.ParseExact(parts(5), DT, CultureInfo.InvariantCulture)
                    }
                    list.Add(rec)
                Catch ex As Exception
                End Try
            Next
            Return list
        End Function

        '------------------------------------------------------------------
        ' 日汇总表
        '------------------------------------------------------------------
        ''' <summary>该日是否已生成过日施工日志</summary>
        Public Function IsDailySummaryExists(day As Date) As Boolean
            Dim prefix = day.ToString(ENC_DATE, CultureInfo.InvariantCulture) & "|"
            For Each line In _fs.ReadAllLines(_paths.DailySummaryFile)
                If line.StartsWith(prefix, StringComparison.Ordinal) Then Return True
            Next
            Return False
        End Function

        ''' <summary>读取某日汇总（不存在返回 Nothing）</summary>
        Public Function ReadDailySummary(day As Date) As DailySummary
            Dim prefix = day.ToString(ENC_DATE, CultureInfo.InvariantCulture) & "|"
            For Each line In _fs.ReadAllLines(_paths.DailySummaryFile)
                If line.StartsWith(prefix, StringComparison.Ordinal) Then
                    Dim parts = line.Split(New Char() {"|"c})
                    If parts.Length < 13 Then Return Nothing
                    Try
                        Return New DailySummary With {
                            .LogDate = Date.ParseExact(parts(0), ENC_DATE, CultureInfo.InvariantCulture),
                            .AdvanceM = Double.Parse(parts(1), CultureInfo.InvariantCulture),
                            .MorningCutCount = Integer.Parse(parts(2), CultureInfo.InvariantCulture),
                            .MorningSupportCount = Integer.Parse(parts(3), CultureInfo.InvariantCulture),
                            .MorningCutMinutes = Double.Parse(parts(4), CultureInfo.InvariantCulture),
                            .MorningSupportMinutes = Double.Parse(parts(5), CultureInfo.InvariantCulture),
                            .NoonCutCount = Integer.Parse(parts(6), CultureInfo.InvariantCulture),
                            .NoonSupportCount = Integer.Parse(parts(7), CultureInfo.InvariantCulture),
                            .NoonCutMinutes = Double.Parse(parts(8), CultureInfo.InvariantCulture),
                            .NoonSupportMinutes = Double.Parse(parts(9), CultureInfo.InvariantCulture),
                            .FaultMinutes = Double.Parse(parts(10), CultureInfo.InvariantCulture),
                            .Remark = parts(11),
                            .GeneratedTime = Date.ParseExact(parts(12), DT, CultureInfo.InvariantCulture)
                        }
                    Catch ex As Exception
                        Return Nothing
                    End Try
                End If
            Next
            Return Nothing
        End Function

        ''' <summary>追加日汇总（同一日只落一次，重复生成时跳过，避免月统计重复）</summary>
        Public Sub AppendDailySummary(summary As DailySummary)
            If summary Is Nothing Then Return
            If IsDailySummaryExists(summary.LogDate) Then Return
            Dim line = String.Join("|", New String() {
                summary.LogDate.ToString(ENC_DATE, CultureInfo.InvariantCulture),
                summary.AdvanceM.ToString("F2", CultureInfo.InvariantCulture),
                summary.MorningCutCount.ToString(CultureInfo.InvariantCulture),
                summary.MorningSupportCount.ToString(CultureInfo.InvariantCulture),
                summary.MorningCutMinutes.ToString("F2", CultureInfo.InvariantCulture),
                summary.MorningSupportMinutes.ToString("F2", CultureInfo.InvariantCulture),
                summary.NoonCutCount.ToString(CultureInfo.InvariantCulture),
                summary.NoonSupportCount.ToString(CultureInfo.InvariantCulture),
                summary.NoonCutMinutes.ToString("F2", CultureInfo.InvariantCulture),
                summary.NoonSupportMinutes.ToString("F2", CultureInfo.InvariantCulture),
                summary.FaultMinutes.ToString("F2", CultureInfo.InvariantCulture),
                Clean(summary.Remark),
                summary.GeneratedTime.ToString(DT, CultureInfo.InvariantCulture)
            })
            _fs.AppendLine(_paths.DailySummaryFile, line)
        End Sub

        ''' <summary>读取某月全部日汇总（月施工日志用）</summary>
        Public Function ReadDailySummaries(month As Date) As List(Of DailySummary)
            Dim list As New List(Of DailySummary)
            Dim prefix = month.ToString("yyyyMM", CultureInfo.InvariantCulture)
            For Each line In _fs.ReadAllLines(_paths.DailySummaryFile)
                If Not line.StartsWith(prefix, StringComparison.Ordinal) Then Continue For
                Dim parts = line.Split(New Char() {"|"c})
                If parts.Length < 13 Then Continue For
                Try
                    Dim item As New DailySummary With {
                        .LogDate = Date.ParseExact(parts(0), ENC_DATE, CultureInfo.InvariantCulture),
                        .AdvanceM = Double.Parse(parts(1), CultureInfo.InvariantCulture),
                        .MorningCutCount = Integer.Parse(parts(2), CultureInfo.InvariantCulture),
                        .MorningSupportCount = Integer.Parse(parts(3), CultureInfo.InvariantCulture),
                        .MorningCutMinutes = Double.Parse(parts(4), CultureInfo.InvariantCulture),
                        .MorningSupportMinutes = Double.Parse(parts(5), CultureInfo.InvariantCulture),
                        .NoonCutCount = Integer.Parse(parts(6), CultureInfo.InvariantCulture),
                        .NoonSupportCount = Integer.Parse(parts(7), CultureInfo.InvariantCulture),
                        .NoonCutMinutes = Double.Parse(parts(8), CultureInfo.InvariantCulture),
                        .NoonSupportMinutes = Double.Parse(parts(9), CultureInfo.InvariantCulture),
                        .FaultMinutes = Double.Parse(parts(10), CultureInfo.InvariantCulture),
                        .Remark = parts(11),
                        .GeneratedTime = Date.ParseExact(parts(12), DT, CultureInfo.InvariantCulture)
                    }
                    list.Add(item)
                Catch ex As Exception
                End Try
            Next
            Return list
        End Function

        Private Shared Function Clean(value As String) As String
            If value Is Nothing Then Return ""
            Return value.Replace("|", "/")
        End Function
    End Class

End Namespace
