﻿# 编译 EBM 施工日志优化版（.NET Framework，使用系统自带 vbc 编译器）
# 用法：powershell -ExecutionPolicy Bypass -File build.ps1
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$srcDir = Join-Path $root 'src'
$outDir = Join-Path $root 'out'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

$candidates = @(
    (Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\vbc.exe'),
    (Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\vbc.exe')
)
$vbc = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $vbc) { throw '未找到 .NET Framework 4.x 的 vbc.exe，请安装 .NET Framework 4.x 或使用 Visual Studio 打开项目。' }

$files = Get-ChildItem $srcDir -Filter *.vb | Sort-Object Name | ForEach-Object { $_.FullName }
$outExe = Join-Path $outDir 'EbmConstructionLog.exe'

& $vbc /nologo /target:exe /platform:anycpu /optionexplicit+ /optionstrict- /optioninfer+ `
    /codepage:65001 /r:System.dll /r:System.Core.dll /out:$outExe $files
if ($LASTEXITCODE -ne 0) { throw "编译失败，退出码 $LASTEXITCODE" }

Write-Host "编译成功：$outExe"
Write-Host "运行自测：powershell -ExecutionPolicy Bypass -File run.ps1"
